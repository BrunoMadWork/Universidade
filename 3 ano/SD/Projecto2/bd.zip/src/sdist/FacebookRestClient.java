package sdist;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

import org.scribe.builder.ServiceBuilder;
import org.scribe.builder.api.FacebookApi;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.model.Verifier;
import org.scribe.oauth.OAuthService;

public class FacebookRestClient extends Thread
{
  private static final String NETWORK_NAME = "Facebook";
  private static final String PROTECTED_RESOURCE_URL = "https://graph.facebook.com/me";
  private static final Token EMPTY_TOKEN = null;
  private Token accessToken;
  private OAuthService service;
  public FacebookRestClient(){
  
    // Replace these with your own api key and secret
    String apiKey = "231446223683755";
    String apiSecret = "36d6b897d9f320bb72498395c24a5693";
    
    
     service = new ServiceBuilder()
                                  .provider(FacebookApi.class)
                                  .apiKey(apiKey)
                                  .apiSecret(apiSecret)
                                  .callback("http://eden.dei.uc.pt/~amaf/echo.php") // Do not change this.
                                  .scope("publish_stream")
                                  .build();
    Scanner in = new Scanner(System.in);

    System.out.println("=== " + NETWORK_NAME + "'s OAuth Workflow ===");
    System.out.println();

    // Obtain the Authorization URL
    System.out.println("Fetching the Authorization URL...");
    String authorizationUrl = service.getAuthorizationUrl(EMPTY_TOKEN);
    System.out.println("Got the Authorization URL!");
    System.out.println("Now go and authorize Scribe here:");
    System.out.println(authorizationUrl);
    System.out.println("And paste the authorization code here");
    System.out.print(">>");
    Verifier verifier = new Verifier(in.nextLine());
    System.out.println();
    
    // Trade the Request Token and Verfier for the Access Token
    System.out.println("Trading the Request Token for an Access Token...");
     accessToken = service.getAccessToken(EMPTY_TOKEN, verifier);
    System.out.println("Got the Access Token!");
    System.out.println("(if your curious it looks like this: " + accessToken + " )");
    System.out.println();

    // Now let's go and ask for a protected resource!
    System.out.println("Now we're going to access a protected resource...");
    OAuthRequest request = new OAuthRequest(Verb.GET, PROTECTED_RESOURCE_URL);
    service.signRequest(accessToken, request);
    Response response = request.send();
    System.out.println("Got it! Lets see what we found...");
    System.out.println();
    System.out.println(response.getCode());
    System.out.println(response.getBody());
    
    System.out.println();
    System.out.println("Thats it man! Go and build something awesome with Scribe! :)");  
    
  }
  
  public String post_on_facebook(String data){
	  System.out.println("Trying to post a simple message...");
    
    OAuthRequest request_post = new OAuthRequest(Verb.POST, "https://graph.facebook.com/me/feed");
    SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z");
    String message = data+"  " + sdf.format(new Date());
    request_post.addBodyParameter("message", message);
    service.signRequest(accessToken, request_post);
    Response response_post = request_post.send();
    System.out.println(response_post.getCode());
    String responseBody = response_post.getBody();
    StringTokenizer st = new StringTokenizer(responseBody, ":}");
    st.nextToken();
    String id=st.nextToken();
    String idf=id.substring(1, id.length()-1);
    System.out.println(responseBody);
    System.out.println("id="+id  );
    System.out.println("idf="+idf  );
    
    return idf;
  }
  
  public void delete_on_facebook(String id){
	  
    System.out.println("Trying to delete...");
    OAuthRequest request_delete = new OAuthRequest(Verb.DELETE, "https://graph.facebook.com/"+id);
    service.signRequest(accessToken, request_delete);
    Response response_delete = request_delete.send();
    System.out.println(response_delete.getCode());
    String response = response_delete.getBody();
    System.out.println(response);
  }
  
  public void post_coment_on_facebook(String data, String id){
	 OAuthRequest request_post = new OAuthRequest(Verb.POST, "https://graph.facebook.com/"+id+"/comments");
	 String message = data;
	 request_post.addBodyParameter("message", message);
	 service.signRequest(accessToken, request_post);
	 Response response_post = request_post.send();
	 System.out.println(response_post.getCode());
	 String responseBody = response_post.getBody();
	 System.out.println(responseBody);
  }
}