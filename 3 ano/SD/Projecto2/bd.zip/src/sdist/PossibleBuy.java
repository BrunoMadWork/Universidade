package sdist;

public class PossibleBuy {

	private int idea_key;
	private float preço;
	private float n_acções;
	private String nome;
	public PossibleBuy(int idea_key, float preço, float n_acções, String nome) {
		super();
		this.idea_key = idea_key;
		this.preço = preço;
		this.n_acções = n_acções;
		this.nome = nome;
	}
	public int getIdea_key() {
		return idea_key;
	}
	public void setIdea_key(int idea_key) {
		this.idea_key = idea_key;
	}
	public float getPreço() {
		return preço;
	}
	public void setPreço(float preço) {
		this.preço = preço;
	}
	public float getN_acções() {
		return n_acções;
	}
	public void setN_acções(float n_acções) {
		this.n_acções = n_acções;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
}