package sdist;
import java.io.File;
import java.io.FileInputStream;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Hashtable;


public interface Bd extends Remote {

	public  void send_querry_nome_passe( ) throws RemoteException;
	public  boolean has_user(String nome) throws RemoteException;
	public  String get_password(String nome) throws RemoteException;
	public   void put_reg_data(String nome, String password) throws RemoteException;
	public   void put_beg_acount_data(String nome, double creditos) throws RemoteException;
	public   double get_creditos(String nome) throws RemoteException;
	public   void put_idea_table_data(String nome,String hashtag, int acções, int acções_totais,float preco,String texto,int tipo) throws RemoteException;
	public   int get_n_topicos() throws RemoteException;
	 public int get_n_posts() throws RemoteException;
	public void puthashtag(String hashtag,int numero) throws RemoteException;
	public void put_all_things(String nome,ArrayList<String> hashtag_arrray,int acções,int tipo,float preco,String texto) throws RemoteException;
	public ArrayList<Topico> getTopicos() throws RemoteException;
	public ArrayList<Idea> getIdeas(int topic_key) throws RemoteException;
	public ArrayList<String> getCorrespondentIdeas(int topic_key) throws RemoteException;
	public ArrayList<Idea> getfullyownIdeas(String nome) throws RemoteException;
	public void deleteIdeas(Idea idea, String nome) throws RemoteException;
	public ArrayList<Idea> getIdeas_to_change(String nome) throws RemoteException;
	public float getPreco(String nome, int idea_key) throws RemoteException;
	public int getNumeroAcções(int idea_key) throws RemoteException;
    public int getNumeroAcçõesCliente(int idea_key) throws RemoteException;
    public ArrayList<SharesTableCell> getsharesTable(int idea_key) throws RemoteException;
    public int getCreditosCliente(String name) throws RemoteException;
    public int getExistingShares(String name,int idea_key) throws RemoteException;
    public boolean jaTemAlgumasShares(String name,int idea_key) throws RemoteException;
    public int getNumberhistorico() throws RemoteException;
    public void transação(String vendedor, String comprador,int acções,float preço,int key, int acções_comprador, int acções_vendedor,int creditos_comprador,int creditos_vendedor) throws RemoteException;
    public void alterar_preço(float new_price, int idea_key, String name) throws RemoteException;    
    public ArrayList<Entrada_historico> get_historico() throws RemoteException;
    public boolean isRoot(String nome) throws RemoteException;
    public void add_to_watchlist(String name, int idea_key) throws RemoteException;
    public ArrayList<Idea> get_watched_ideas(String nome) throws RemoteException;
    public void retirar_saldo(String nome,float quantidade ) throws RemoteException;
    
    
    
    
    public Hashtable<String,String> getArrayUsers() throws RemoteException;
    public Login_data_bucket getNomes() throws RemoteException;
    public  ArrayList<Idea> getAllIdeas() throws RemoteException;
    public  ArrayList<Idea> getIdeasByName(String palavra) throws RemoteException;
    public  ArrayList<Idea> getPartialownIdeas(String nome) throws RemoteException;
	public  void put_all_things(String nome,ArrayList<String> hashtag_arrray,int acções,int tipo,float preco,String texto,String fi,long tam,FileInputStream is) throws RemoteException;
	public void Takeover_the_root(String nome,Idea idea) throws RemoteException; //não confio minimamente na minha concentração
	public  void add_to_wacthlist(String nome,Idea idea) throws RemoteException;
	public  void new_pedido(String nome,Idea idea,float limite,float numero_acções) throws RemoteException;
	public  void getData_requests() throws RemoteException;
	public  ArrayList<PossibleBuy> getPossibleBuys(Idea idea, float preço) throws RemoteException;
	public  float getShares(String nome, int idea_key) throws RemoteException;
	public  void transação(String vendedor, String comprador,float acções,float preço,int key, float acções_comprador, float acções_vendedor,float creditos_comprador,float creditos_vendedor) throws RemoteException;
	public  void new_pedido(String nome,int idea,float limite,float numero_acções) throws RemoteException;
	public  void Transaction_handler() throws RemoteException;
	public  float preço_mais_baixo(int idea_key) throws RemoteException;
	public boolean HasShares(int idea, String nome)  throws RemoteException;
	public  void new_share_entry(int idea, String nome ,float preço) throws RemoteException;
	public  ArrayList<Idea> GetHallOffameIdeas() throws RemoteException;
	public  ArrayList<Entrada_historico> get_historico_by_idea(int idea_key) throws RemoteException;
	public  Entrada_historico notification_from_bd(int idea_key, String nome) throws RemoteException;
	public void subscribe(String name, Notificacoes c) throws RemoteException ;
	public void insert_on_facebook_table(int idea, String post_idea) throws RemoteException;
	public String get_idea_key_from_facebook (int idea_key) throws RemoteException;
	public void delete_deleters (int idea_key) throws RemoteException;
	
    
}

   
    

