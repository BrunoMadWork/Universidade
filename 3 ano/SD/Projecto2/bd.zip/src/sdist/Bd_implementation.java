package sdist;
import java.io.File;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
//Create table pedidos (name VARCHAR(50),idea_key NUMERIC(15,0), limite Numeric(30,10),numero_acções Numeric (30,0),ordem Numeric(15,0),PRIMARY KEY(name,idea_key))
//Create table halloffame (idea_key Number(15,0),Primary key(idea_key))
public class Bd_implementation  extends UnicastRemoteObject implements Bd  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Connection connection;
	private ArrayList<Transaction> array_trasações;
	FacebookRestClient facebookClient;
	private Notificacoes client;







	public Bd_implementation() throws RemoteException {

		System.out.println("-------- Oracle JDBC Connection Testing ------");

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your Oracle JDBC Driver?");
			e.printStackTrace();
			return;

		}

		System.out.println("Oracle JDBC Driver Registered!");

		connection = null;

		try {

			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.56.101:1521:XE", "bruno",
					"bruno8701");

		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}

		if (connection != null) {
			System.out.println("You made it, take control your database now!");
		} else {
			System.out.println("Failed to make connection!");
		}
		

		 facebookClient=new FacebookRestClient(); ;

	}

	public void subscribe(String name, Notificacoes c) throws RemoteException {
		System.out.println("Subscribing " + name);
		System.out.print("> ");
		client = c;
	}





	public synchronized void send_querry_nome_passe() throws RemoteException{


		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT name,password FROM login");

			while (rs.next()) {
				String nome = rs.getString(1);
				String password = rs.getString(2);
				System.out.println(nome + " " + password);
			}

		} catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public synchronized Connection getConnection() {
		return connection;
	}







	public synchronized void setConnection(Connection connection) {
		this.connection = connection;
	}








	public synchronized boolean has_user(String nome) throws RemoteException {
		// TODO Auto-generated method stub
		Statement stmt;
		Boolean bool=false;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT name FROM login WHERE name='"+nome+"'");
			if(rs!=null){
				while(rs.next()){

					if(rs.getString(1).equals(nome)){
						return true;
					}
				}
				return false;
			}
		}
		catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return bool;
	}







	public synchronized String get_password(String nome) throws RemoteException {
		Statement stmt;
		ResultSet rs ;
		String temp=null;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT password FROM login WHERE name='"+nome+"'");
			rs.next();		        	
			temp= rs.getString(1);


		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		/*if(temp==null){
		        	temp="asjzcjvzxjvzjvdsvsjgsbabv";
		        }*/
		System.out.println(temp);
		return temp;
	}








	public synchronized void put_reg_data(String nome, String password) throws RemoteException {
		Statement stmt;


		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into login (name, password,isroot) VALUES('"+nome +"','"+ password+"',0)");

		}
		catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void  put_beg_acount_data(String nome, double creditos) throws RemoteException{

		Statement stmt;


		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into saldos (name, creditos) VALUES('"+nome +"',"+ creditos+")");

		}
		catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


	}

	public synchronized double  get_creditos(String nome) throws RemoteException{

		Statement stmt;
		ResultSet rs ;
		double temp = 0; ////TER MUIIIIIIIIIIIITO CUIDADO
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT creditos FROM saldos WHERE name='"+nome+"'");

			rs.next();
			temp= rs.getDouble(1);

			

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return temp;


	}




	public synchronized void put_idea_table_data(String nome,String hashtag, int acções, int acções_totais,float preco,String texto,int tipo) throws RemoteException{



		Statement stmt;


		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("INSERT Into idea_table(acções,acções_totais,preco,texto,tipo,idea_key) Values("+acções+","+acções_totais+","+preco+",'"+texto+"',"+tipo+","+0+")");
			//altera valor
		}
		catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public synchronized void  puthashtag(String hashtag,int numero) throws RemoteException{
		//ver se tem, se não tiver mete senão deixar tar
		ArrayList<String> array_temp=new ArrayList<String>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery(
					"SELECT hashtag from topicos");
			if(rs!=null){
				while(rs.next()){

					array_temp.add(rs.getString(1));

				}
			}	
		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		int i;
		boolean esta=false;

		for(i=0;i<array_temp.size();i++){
			if(array_temp.get(i).equals(hashtag)){
				esta=true;
			}
		}

		if (esta==false){







			try {		       
				stmt =  connection.createStatement();
				stmt.executeQuery("Insert into topicos (hashtag,topic_key) VALUES("+hashtag+","+numero+1+")");////ALTERAR!!! METER A CONTAR
				//altera valor
			}
			catch (SQLException ex) {
				System.out.println("error code : " + ex.getErrorCode());
				System.out.println("error message : " + ex.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}



	public synchronized int  get_n_topicos() throws RemoteException{

		Statement stmt;
		ResultSet rs ;
		int n_topicos = 0;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select count(*)from topicos");
			rs.next();


			n_topicos= rs.getInt(1);



		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return n_topicos;

	}
	public synchronized int  get_n_posts() throws RemoteException{

		Statement stmt;
		ResultSet rs ;
		int n_posts = 0;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select count(*)from idea_table");
			rs.next();

			n_posts= rs.getInt(1);




		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n_posts;

	}

	public synchronized void put_all_things(String nome,ArrayList<String> hashtag_arrray,int acções,int tipo,float preco,String texto) throws RemoteException{


		ArrayList<String> temp=hashtag_arrray;
		Statement stmt;
		ResultSet rs ;
		System.out.println(temp);

		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("INSERT into idea_table(acções_totais , tipo ,texto , idea_key ) VALUES ("+acções+","+tipo+",'"+texto+"',"+(getMaxIdeaKey()+1)+")");
			stmt.executeQuery("INSERT into shares_table(nome ,acções,idea_key,preco) VALUES ('"+nome+"',"+acções+","+(getMaxIdeaKey())+","+preco+")");

			int i;

			for(i=0;i<temp.size();i++){
				int n_hashtags=get_n_topicos();
				System.out.println("Ola");

				rs=stmt.executeQuery("select count(*) from topicos where hashtag='"+temp.get(i)+"'");
				rs.next();
				if(rs.getInt(1)==0){


					stmt.executeQuery("Insert into topicos (hashtag,topic_key) VALUES('"+temp.get(i)+"',"+(n_hashtags+1)+")");
					stmt.executeQuery("Insert into i_t (idea_key ,topic_key ) VALUES("+(getMaxIdeaKey())+","+(n_hashtags+1)+")"); //atenção aqui


				}else{ //quando há la coisas
					//associar só
					int id_hashtag;

					rs=stmt.executeQuery("SELECT topic_key from topicos where hashtag='"+temp.get(i)+"'");
					rs.next();
					id_hashtag=rs.getInt(1);

					stmt.executeQuery("Insert into i_t (idea_key ,topic_key ) VALUES("+(getMaxIdeaKey())+","+id_hashtag+")"); //tava trocado?



				}

			}

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		//Ver se  está la 
		String id=facebookClient.post_on_facebook(texto);
		insert_on_facebook_table(getMaxIdeaKey(), id);




	}
	public synchronized void put_all_things(String nome,ArrayList<String> hashtag_arrray,int acções,int tipo,float preco,String texto,String fi,long tam,FileInputStream is) throws RemoteException{


		ArrayList<String> temp=hashtag_arrray;
		Statement stmt;
		ResultSet rs ;
		System.out.println(temp);
		PreparedStatement ps;
		try {		

			stmt =  connection.createStatement();
			stmt.executeQuery("INSERT into idea_table(acções_totais , tipo ,texto , idea_key,file_name ) VALUES ("+acções+","+tipo+",'"+texto+"',"+(getMaxIdeaKey()+1)+",'"+fi+"')");
			ps = connection.prepareStatement("insert into idea_table values (?,?) where idea_key="+getMaxIdeaKey()+";");
			System.out.println(ps.toString());
			//ps = connection.prepareStatement("INSERT into idea_table(acções_totais , tipo ,texto , idea_key,file_name, file ) VALUES ("+acções+","+tipo+",'"+texto+"',"+(getMaxIdeaKey()+1)+","+file+","+?+")");

			ps.setInt(1, 1);
			//File tm=new File(file);
			//is = new FileInputStream(tm);
			
			ps.setBinaryStream(2, is,tam);
			ps.executeUpdate();

			stmt.executeQuery("INSERT into shares_table(nome ,acções,idea_key,preco) VALUES ('"+nome+"',"+acções+","+(getMaxIdeaKey())+","+preco+")");

			int i;

			for(i=0;i<temp.size();i++){
				int n_hashtags=get_n_topicos();
				System.out.println("Ola");

				rs=stmt.executeQuery("select count(*) from topicos where hashtag='"+temp.get(i)+"'");
				rs.next();
				if(rs.getInt(1)==0){


					stmt.executeQuery("Insert into topicos (hashtag,topic_key) VALUES('"+temp.get(i)+"',"+(n_hashtags+1)+")");
					stmt.executeQuery("Insert into i_t (idea_key ,topic_key ) VALUES("+(getMaxIdeaKey())+","+(n_hashtags+1)+")"); //atenção aqui


				}else{ //quando há la coisas
					//associar só
					int id_hashtag;

					rs=stmt.executeQuery("SELECT topic_key from topicos where hashtag='"+temp.get(i)+"'");
					rs.next();
					id_hashtag=rs.getInt(1);

					stmt.executeQuery("Insert into i_t (idea_key ,topic_key ) VALUES("+(getMaxIdeaKey())+","+id_hashtag+")"); //tava trocado?



				}

			}

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		//Ver se  está la 

		//String id = 
		String id=facebookClient.post_on_facebook(texto);
		insert_on_facebook_table(getMaxIdeaKey(), id);
		


	}

	public synchronized ArrayList<Topico> getTopicos() throws RemoteException{
		ArrayList<Topico> array=new ArrayList<Topico>();
		Statement stmt;
		ResultSet rs ;

		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select hashtag,topic_key from topicos");
			while (rs.next()) {
				array.add(new Topico(rs.getString(1), rs.getInt(2)));

			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;

	}

	public synchronized ArrayList<Idea> getIdeas(int topic_key) throws RemoteException{
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select i.acções_totais, i.tipo,i.texto,i.idea_key from idea_table i, i_t it, topicos t where t.topic_key=it.topic_key and it.idea_key=i.idea_key and it.topic_key="+topic_key+" and i.idea_key not in (select idea_key from halloffame)");
			while (rs.next()) {



				array.add(new Idea(rs.getInt(1), 0,rs.getInt(2), rs.getString(3),rs.getInt(4)));

			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}


	public synchronized ArrayList<String> getCorrespondentIdeas(int topic_key) throws RemoteException{
		ArrayList<String> array=new ArrayList<String>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select hashtag from idea_table i, i_t it, topicos t where t.topic_key=it.topic_key and it.idea_key=i.idea_key and i.idea_key='1'");
			while (rs.next()) {



				array.add(rs.getString(1));

			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}
	public synchronized ArrayList<Idea> getfullyownIdeas(String nome) throws RemoteException{
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select distinct s.acções, i.tipo,i.texto,i.idea_key from i_t it, shares_table s, topicos t, idea_table i where i.idea_key=s.idea_key and i.idea_key=it.idea_key and it.topic_key=t.topic_key and s.acções=i.acções_totais and s.nome='"+nome+"' and i.idea_key not in (select idea_key from halloffame)");
			while (rs.next()) {


				array.add(new Idea(rs.getInt(1), 0,rs.getInt(2), rs.getString(3),rs.getInt(4)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}

	public synchronized void deleteIdeas(Idea idea, String nome) throws RemoteException{
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			//stmt.executeQuery("delete from idea_table where texto='"+ idea.getTexto()+"' and idea_key="+idea.getIdea_key()+"; delete from shares_table where nome='"+nome+"' and idea_key="+idea.getIdea_key()+";delete from i_t where idea_key="+idea.getIdea_key()+";");
			//stmt.executeQuery("delete from idea_table where texto='"+idea.getTexto()+"' and idea_key="+ idea.getIdea_key()+";delete from shares_table where nome='"+nome+"' and idea_key="+idea.getIdea_key()+";delete from i_t where idea_key="+idea.getIdea_key()+";");
			//stmt.executeQuery("delete from idea_table where texto="+idea.getTexto()+" and idea_key=" +idea.getIdea_key()+";delete from shares_table where nome='"+ nome+"' and idea_key="+idea.getIdea_key()+"; delete from i_t where idea_key="+idea.getIdea_key()+";");
			stmt.executeQuery("delete from idea_table where texto='"+idea.getTexto()+"' and idea_key=" +idea.getIdea_key());
			stmt.executeQuery("delete from shares_table where nome='"+ nome+"' and idea_key="+idea.getIdea_key());
			stmt.executeQuery("delete from i_t where idea_key="+idea.getIdea_key());

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(!get_idea_key_from_facebook (idea.getIdea_key()).equals("bananas")){
			int idea_key= idea.getIdea_key();
			facebookClient.delete_on_facebook(get_idea_key_from_facebook (idea_key));//mudar parametro para id do post ou para nenhum
			delete_deleters (idea_key);

		}
	}

	public synchronized ArrayList<Idea> getIdeas_to_change(String nome) throws RemoteException{
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select distinct s.acções, i.tipo,i.texto,i.idea_key from i_t it, shares_table s, topicos t, idea_table i where i.idea_key=s.idea_key and i.idea_key=it.idea_key and it.topic_key=t.topic_key  and s.nome='"+nome+"'");
			while (rs.next()) {


				array.add(new Idea(rs.getInt(1),0,rs.getInt(2), rs.getString(3),rs.getInt(4)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}

	public synchronized float getPreco(String nome, int idea_key) throws RemoteException{
		float preço = 0;
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select preco from shares_table where nome='"+nome+"' and idea_key="+idea_key);
			rs.next() ;

			
			preço=rs.getFloat(1);




		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return preço;


	}
	public synchronized void settPreco(String nome, int idea_key, int preço) throws RemoteException{
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("update shares_table SET preco='"+preço+"' where nome='"+nome+"' and idea_key="+idea_key);






		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}
	public synchronized int getNumeroAcções(int idea_key) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int numero_acções = 1000; //se ouver porcaria ao menos da o que devia xD
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT acções_totais from idea_table where idea_key="+idea_key);
			rs.next() ;
			numero_acções=rs.getInt(1);






		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return numero_acções;
	}

	public synchronized int getNumeroAcçõesCliente(int idea_key) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int numero_acções = 1000; //se ouver porcaria ao menos da o que devia xD
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT s.acções from idea_table i ,shares_table s where i.idea_key="+idea_key+" and s.idea_key=i.idea_key");
			rs.next() ;
			numero_acções=rs.getInt(1);






		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return numero_acções;
	}
	public synchronized ArrayList<SharesTableCell> getsharesTable(int idea_key) throws RemoteException{
		ArrayList<SharesTableCell> array=new ArrayList<SharesTableCell>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT nome,acções,idea_key, preco from shares_table where idea_key="+idea_key);
			while (rs.next()) {


				array.add(new SharesTableCell(rs.getString(1),rs.getInt(2),rs.getInt(3),rs.getInt(4)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}

	public  synchronized int getCreditosCliente(String name) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int numero_creditos=1000; //se ouver porcaria ao menos da o que devia xD
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT creditos from saldos where name='"+name +"'");
			rs.next() ;
			numero_creditos=rs.getInt(1);






		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return numero_creditos;
	}
	public synchronized  boolean jaTemAlgumasShares(String name,int idea_key) throws RemoteException{
		System.out.println("a1");
		Statement stmt;
		ResultSet rs ;
		boolean tem_shares=false; //se ouver porcaria ao menos da o que devia xD
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("select count(*) from shares_table where nome='"+name+"' and idea_key="+idea_key);
			rs.next() ;
			int temp=rs.getInt(1);
			if(temp>0){
				tem_shares=true;
			}





		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return tem_shares;
	}
	public synchronized int getExistingShares(String name,int idea_key) throws RemoteException{ //por celulas que ja existam
		Statement stmt;
		ResultSet rs ;
		int temp=0; //se ouver porcaria ao menos da o que devia xD
		try {		       
			stmt =  connection.createStatement();
			System.out.println("a2");
			rs=stmt.executeQuery("select acções from shares_table where nome='"+name+"' and idea_key="+idea_key);
			System.out.println("a3");
			rs.next() ;
			temp=rs.getInt(1);






		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return temp;
	}
	public synchronized int getNumberhistorico() throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int n=0; //se ouver porcaria ao menos da o que devia xD
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("select count(*) from historico");
			rs.next() ;
			n =rs.getInt(1);






		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}


		return n;
	}

	public synchronized void transação(String vendedor, String comprador,int acções,float preço,int key, int acções_comprador, int acções_vendedor,int creditos_comprador,int creditos_vendedor) throws RemoteException{
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			System.out.println(HasShares(key, comprador));
			if(!HasShares(key, comprador)){
				System.out.println("novo registo criado");
				new_share_entry(key, comprador, preço);
			}
			System.out.println("00000000000");
			stmt.executeQuery("UPDATE shares_table SET acções="+(acções_comprador+acções)+" where nome='"+comprador+"' and idea_key="+key);
			System.out.println("111111111");
			stmt.executeQuery("UPDATE shares_table SET acções="+(acções_vendedor-acções)+" where nome='"+vendedor+"' and idea_key="+key);
			//System.out.println("222222222");
			//stmt.executeQuery("UPDATE saldos SET creditos="+(creditos_comprador-(acções*preço))+"  where name='"+comprador+"'");
			//System.out.println("333333333");
			//stmt.executeQuery("UPDATE saldos SET creditos="+(creditos_comprador+(acções*preço))+"  where name='"+vendedor+"'");
			//System.out.println("4444444444");
			stmt.executeQuery("UPDATE saldos SET creditos="+(get_creditos(comprador)-(acções*preço))+"  where name='"+comprador+"'");
			System.out.println("333333333");
			stmt.executeQuery("UPDATE saldos SET creditos="+(get_creditos(vendedor)+(acções*preço))+"  where name='"+vendedor+"'");
			System.out.println("4444444444");
			stmt.executeQuery("Insert into historico(vendedor,comprador,acções,preco,idea_key,n_compra) Values('"+ vendedor+"','"+comprador+"',"+acções+","+preço+","+key+","+(getMaxn_compra()+1)+")");	
			System.out.println("55555555");

			client.notificate_users(comprador+" comprou "+acções+" acções a "+vendedor+" por "+preço);
			facebookClient.post_on_facebook(comprador+" comprou "+acções+" acções a "+vendedor+" por "+preço);
			System.out.println("Mandou notificacao");


		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}
	public synchronized int getMaxIdeaKey()throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int max=0; 
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT max(idea_key) from idea_table");
			if(rs.next()==false){

				max=0;
			}
			else{
				max=rs.getInt(1);
			}



		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return max;
	}

	public synchronized int getMaxn_compra()throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int max=0; 
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT max(n_compra) FROM historico");
			if(rs.next()==false){

				max=0;
			}
			else{
				max=rs.getInt(1);
			}


		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return max;
	}

	public synchronized void alterar_preço(float preço, int idea_key, String name) throws RemoteException{
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("UPDATE shares_table set(preco) = ("+ preço+") where idea_key="+idea_key+" and nome='"+name +"'");

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		Transaction_handler();

	}
	public synchronized ArrayList<Entrada_historico> get_historico() throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		ArrayList<Entrada_historico> array_historico=new ArrayList<Entrada_historico>();

		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT * from historico");
			while (rs.next()) {

				array_historico.add(new Entrada_historico(rs.getString(1), rs.getString(2), rs.getInt(3),	rs.getFloat(4), rs.getInt(5), rs.getInt(6),0) );
				array_historico.add(new Entrada_historico(rs.getString(1), rs.getString(2), rs.getInt(3),	rs.getFloat(4), rs.getInt(5), rs.getInt(6),1) );


			}

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return array_historico;


	}

	public synchronized boolean isRoot(String nome) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int temp=0; 
		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT isroot FROM login where name='"+nome +"'");
			rs.next();
			temp=rs.getInt(1);
			if(temp==1) {return true;}


			else{ return false;}



		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public synchronized void add_to_watchlist(String name, int idea_key) throws RemoteException{
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into watchlist(name,idea_key) VALUES ('"+name+"',"+idea_key+")");

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}

	public synchronized  ArrayList<Idea> get_watched_ideas(String nome) throws RemoteException{ //rever depois
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select i.acções_totais, i.tipo,i.texto,i.idea_key from idea_table i,watchlist w where w.idea_key=i.idea_key and w.name='"+nome+"' and i.idea_key not in (select idea_key from halloffame)");
			while (rs.next()) {



				array.add(new Idea(rs.getInt(1), 0,rs.getInt(2), rs.getString(3),rs.getInt(4)));

			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}
	public void retirar_saldo(String nome,float quantidade ) throws RemoteException{ // o programa em si é que tem de verificar se nao vai por a zero

		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("UPDATE saldos SET creditos="+(get_creditos(nome)-quantidade)+" where name='"+nome+"')");
			System.out.println("Tirou"+nome +" ");

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}




















	public Hashtable<String,String> getArrayUsers() throws RemoteException{
		Statement stmt;
		Hashtable<String,String> hash=null;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT name,password FROM login");
			if(rs!=null){
				while(rs.next()){
					hash.put(rs.getString(1), rs.getString(2));

				}
			}
		}
		catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash;
	}


	synchronized public Login_data_bucket getNomes() throws RemoteException{
		Statement stmt;
		ArrayList<String> array=new ArrayList<String>();
		ArrayList<Integer> array_int=new ArrayList<Integer>();
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("SELECT name, isRoot FROM login");

			while(rs.next()){
				array.add(rs.getString(1));
				array_int.add(rs.getInt(2));	
			}
		}

		catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new Login_data_bucket(array,array_int);
	}

	public synchronized ArrayList<Idea> getAllIdeas() throws RemoteException{
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select acções_totais, tipo,texto,idea_key from idea_table where idea_key not in (select idea_key from halloffame) ");
			while (rs.next()) {



				array.add(new Idea(rs.getInt(1), 0,rs.getInt(2), rs.getString(3),rs.getInt(4)));

			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}
	public synchronized ArrayList<Idea> getIdeasByName(String palavra) throws RemoteException{
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select i.acções_totais, i.tipo,i.texto,i.idea_key from idea_table i, i_t it, topicos t where t.topic_key=it.topic_key and it.idea_key=i.idea_key and i.texto like'"+palavra+"%' and i.idea_key not in (select idea_key from halloffame)");
			while (rs.next()) {



				array.add(new Idea(rs.getInt(1), 0,rs.getInt(2), rs.getString(3),rs.getInt(4)));

			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}
	public synchronized ArrayList<Idea> getPartialownIdeas(String nome) throws RemoteException{
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select distinct s.acções, i.tipo,i.texto,i.idea_key from i_t it, shares_table s, topicos t, idea_table i where i.idea_key=s.idea_key and i.idea_key=it.idea_key and it.topic_key=t.topic_key and s.nome='"+nome+"' and i.idea_key not in (select idea_key from halloffame)");
			while (rs.next()) {


				array.add(new Idea(rs.getInt(1), 0,rs.getInt(2), rs.getString(3),rs.getInt(4)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;


	}

	public synchronized void Takeover_the_root(String nome,Idea idea) throws RemoteException{ //não confio minimamente na minha concentração
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into halloffame (idea_key) values("+ idea.getIdea_key()+") ");
			stmt.executeQuery("UPDATE saldos SET creditos=("+get_creditos(nome)+"shares_table.acções*shares_table.preco) where saldos.name=shares_table.name and shares_table.idea_key="+idea.getIdea_key()); //verificar
			stmt.executeQuery("delete from shares_table where idea_key="+idea.getIdea_key());









		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}

	public synchronized void add_to_wacthlist(String nome,Idea idea) throws RemoteException{ 
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into watchlist (name,idea_key) values ('"+nome+"',"+idea.getIdea_key() +") ");









		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}
	public synchronized int numero_pedidos() throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		int temp = 0;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select count(*) from pedidos");
			while (rs.next()) {


				temp=rs.getInt(1);


			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return temp;


	}
	public synchronized void new_pedido(String nome,Idea idea,float limite,float numero_acções) throws RemoteException{ 
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into pedidos (name,idea_key,limite,numero_acções,ordem) values ('"+nome+"',"+idea.getIdea_key() +","+limite+","+ numero_acções+","+(numero_pedidos()+1)+") ");









		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}
	public synchronized void new_pedido(String nome,int idea,float limite,float numero_acções) throws RemoteException{ 
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			stmt.executeQuery("Insert into pedidos (name,idea_key,limite,numero_acções,ordem) values ('"+nome+"',"+idea +","+limite+","+ numero_acções+","+(numero_pedidos()+1)+") ");









		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}
	public synchronized void getData_requests() throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		array_trasações=new ArrayList<Transaction>();
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select * from pedidos order by ordem desc");
			while (rs.next()) {

				array_trasações.add(new Transaction(rs.getString(1),rs.getInt(2),rs.getFloat(3),rs.getFloat(4),rs.getInt(5)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public synchronized ArrayList<PossibleBuy> getPossibleBuys(int idea, float preço) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		ArrayList<PossibleBuy> temp = new ArrayList<PossibleBuy>();
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select s.preco,s.acções,s.nome from idea_table i, shares_table s where i.idea_key="+idea+" and i.idea_key=s.idea_key and s.preco<="+preço+" order by s.preco desc");
			while (rs.next()) {

				temp.add(new PossibleBuy(idea,rs.getFloat(1),rs.getFloat(2),rs.getString(3)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	
	public synchronized float getShares(String nome, int idea_key) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		float temp = 0;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select nvl(acções,0) from shares_table where nome='"+nome+"' and idea_key="+idea_key);
			rs.next();

			temp=rs.getFloat(1);


			

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	public synchronized void transação(String vendedor, String comprador,float acções,float preço,int key, float acções_comprador, float acções_vendedor,float creditos_comprador,float creditos_vendedor) throws RemoteException{
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			if(!HasShares(key, comprador)){
				System.out.println("novo registo criado");
				new_share_entry(key, comprador, preço);
			}
			System.out.println("00000000000");
			stmt.executeQuery("UPDATE shares_table SET acções="+(acções_comprador+acções)+" where nome='"+comprador+"' and idea_key="+key);
			System.out.println("111111111");
			stmt.executeQuery("UPDATE shares_table SET acções="+(acções_vendedor-acções)+" where nome='"+vendedor+"' and idea_key="+key);
			//System.out.println("222222222");
			//stmt.executeQuery("UPDATE saldos SET creditos="+(creditos_comprador-(acções*preço))+"  where name='"+comprador+"'");
			//System.out.println("333333333");
			//stmt.executeQuery("UPDATE saldos SET creditos="+(creditos_comprador+(acções*preço))+"  where name='"+vendedor+"'");
			//System.out.println("4444444444");
			stmt.executeQuery("UPDATE saldos SET creditos="+(get_creditos(comprador)-(acções*preço))+"  where name='"+comprador+"'");
			System.out.println("333333333");
			stmt.executeQuery("UPDATE saldos SET creditos="+(get_creditos(vendedor)+(acções*preço))+"  where name='"+vendedor+"'");
			System.out.println("4444444444");
			stmt.executeQuery("Insert into historico(vendedor,comprador,acções,preco,idea_key,n_compra) Values('"+ vendedor+"','"+comprador+"',"+acções+","+preço+","+key+","+(getMaxn_compra()+1)+")");	
			System.out.println("55555555");
	
			client.notificate_users(comprador+" comprou "+acções+" acções a "+vendedor+" por "+preço);
			System.out.println("\nMandou notificacao");
			
			if(!get_idea_key_from_facebook (key).equals("bananas")){
				facebookClient.post_coment_on_facebook(comprador+" comprou "+acções+" acções a "+vendedor+" por "+preço,get_idea_key_from_facebook (key));//mudar parametro para id do post ou para nenhum
			}

			




		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}
	public synchronized void Transaction_handler() throws RemoteException{

		getData_requests();
		ArrayList<PossibleBuy> possible = new ArrayList<PossibleBuy>();
		System.out.println(array_trasações);
		int i,j,z;
		if(!(array_trasações.isEmpty())){
			for(i=0;i<array_trasações.size();i++){
				possible=getPossibleBuys(array_trasações.get(i).getIdea_key(), array_trasações.get(i).getLimite());
				System.out.println(possible);

			
			if(!(possible.isEmpty())){ // fazer as transações e apagar o request no fim
				//(String vendedor, String comprador,int acções,float preço,int key, int acções_comprador, int acções_vendedor,int creditos_comprador,int creditos_vendedor)
				//ver se o saldo do men aguneta
				//	public synchronized void transação(String vendedor, String comprador,int acções,float preço,int key, int acções_comprador, int acções_vendedor,int creditos_comprador,int creditos_vendedor) throws RemoteException{

				for(j=0;j<possible.size();j++){

					
					//float numero_acções_maximo =array_trasações.get(i).getNumero();
					//int sizeOfPossivel=possible.size();
					//for(z=0;z<sizeOfPossivel;z++){
						//coisas para enfiar la
						String nome_vendedor=possible.get(j).getNome();
						String nome_comprador=array_trasações.get(i).getNome();
						float n_acções=array_trasações.get(i).getNumero();
						float preço=possible.get(j).getPreço();
						int idea_key=array_trasações.get(i).getIdea_key();
						float acções_comprador=getShares(array_trasações.get(i).getNome(),idea_key);
						float acções_vendedor=getShares(possible.get(j).getNome(),idea_key);
						float creditos_comprador=getCreditosCliente(nome_comprador);
						float creditos_vendedor =getCreditosCliente(nome_vendedor);


						if(n_acções<=possible.get(j).getN_acções()){  //se o pedido for menor ou que o possivel
							if(!possible.get(j).getNome().equals(array_trasações.get(i).getNome() )){
								transação(nome_vendedor,nome_comprador ,n_acções,preço,idea_key,acções_comprador,acções_vendedor, creditos_comprador ,creditos_vendedor);
								//apagar transação
								deletePedido(array_trasações.get(i).getOrder());
								//array_trasações.get(i).setNumero(n_acções-possible.get(j).getN_acções()); //negativos
							//if(array_trasações.get(i).getNumero()<=0){
						//		break;
						//	}
							//calbak aqui
							}
						}
						else if(n_acções>possible.get(j).getN_acções()){
							if(!possible.get(j).getNome().equals(array_trasações.get(i).getNome() )){
							n_acções=possible.get(j).getN_acções();
							transação(nome_vendedor,nome_comprador ,n_acções,preço,idea_key,acções_comprador,acções_vendedor, creditos_comprador ,creditos_vendedor);
							//meter nova
							new_pedido(nome_comprador,idea_key,preço,array_trasações.get(i).getNumero()-possible.get(j).getN_acções());
							//apagar transação e por outra
							deletePedido(array_trasações.get(i).getOrder());
							
							}
							// ou aqui
						}
					//}
					
				}

			}

			}


		}

	}
	public synchronized void deletePedido(int ordem) throws RemoteException{ //calback aqui ou nao
		Statement stmt;
		try {		       
			stmt =  connection.createStatement();
			
			stmt.executeQuery("delete from pedidos where ordem='"+ordem+"'");

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}



	}







	@Override
	public ArrayList<PossibleBuy> getPossibleBuys(Idea idea, float preço){
		Statement stmt;
		ResultSet rs ;
		ArrayList<PossibleBuy> temp = new ArrayList<PossibleBuy>();
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select s.preco,s.acções,s.nome from idea_table i, shares_table s where i.idea_key="+idea.getIdea_key()+" and i.idea_key=s.idea_key and s.preco<="+preço+" order by s.preco desc");
			while (rs.next()) {

				temp.add(new PossibleBuy(idea.getIdea_key(),rs.getFloat(1),rs.getFloat(2),rs.getString(3)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp;
	}
	
	
	
	public synchronized float preço_mais_baixo(int idea_key) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		float temp = 0;
		try{
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("select min(preco) from shares_table where idea_key='"+idea_key+"'");
			rs.next();


				temp=rs.getFloat(1);


			

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return temp;


	}
	public synchronized boolean HasShares(int idea, String nome) throws RemoteException{ //muahaha
		Statement stmt;
		ResultSet rs ;
		boolean bool=false;
		try {		       
			stmt =  connection.createStatement();
			System.out.println("Vai executar a query");
			rs =  stmt.executeQuery("select count(*) from shares_table where nome='"+nome+"' and idea_key="+idea);
			//rs.next();
			if(rs.getInt(1)>0){
				bool=true;
			}

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("chegou ao fim da função");

		return bool;
	}
	
	public synchronized void new_share_entry(int idea, String nome ,float preço) throws RemoteException{ 
		Statement stmt;

		try {		       
			stmt =  connection.createStatement();
			  stmt.executeQuery("insert into shares_table (nome,acções,idea_key,preco) values ('"+nome+"',0,"+idea+","+preço+")");
			

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized ArrayList<Idea> GetHallOffameIdeas() throws RemoteException{ 
		ArrayList<Idea> array=new ArrayList<Idea>();
		Statement stmt;
		ResultSet rs ;
		try {		       
			stmt =  connection.createStatement();
			rs =  stmt.executeQuery("Select distinct tipo,texto,idea_key from idea_table where idea_key  in (select idea_key from halloffame)") ;
			while (rs.next()) {


				array.add(new Idea(0, 0,rs.getInt(1), rs.getString(2),rs.getInt(3)));



			}	

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return array;
	
}
	
	public synchronized ArrayList<Entrada_historico> get_historico_by_idea(int idea_key) throws RemoteException{
		Statement stmt;
		ResultSet rs ;
		ArrayList<Entrada_historico> array_historico=new ArrayList<Entrada_historico>();

		try {		       
			stmt =  connection.createStatement();
			rs=stmt.executeQuery("SELECT * from historico where idea_key="+idea_key);
			while (rs.next()) {

				array_historico.add(new Entrada_historico(rs.getString(1), rs.getString(2), rs.getInt(3),	rs.getInt(4), rs.getInt(5), rs.getInt(6),0) );
				array_historico.add(new Entrada_historico(rs.getString(1), rs.getString(2), rs.getInt(3),	rs.getInt(4), rs.getInt(5), rs.getInt(6),1) );


			}

		}  catch (SQLException ex) {
			System.out.println("error code : " + ex.getErrorCode());
			System.out.println("error message : " + ex.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return array_historico;


	}
	
	


public synchronized Entrada_historico notification_from_bd(int idea_key, String nome) throws RemoteException{
	Statement stmt;
	ResultSet rs ;
	Entrada_historico entrada=null;

	try {		       
		stmt =  connection.createStatement();
		rs=stmt.executeQuery("SELECT distinct * from historico where idea_key="+ idea_key+" and comprador='"+ nome+"' order by n_compra desc;");
		while (rs.next()) {

			entrada= new Entrada_historico(rs.getString(1), rs.getString(2), rs.getInt(3),	rs.getInt(4), rs.getInt(5), rs.getInt(6),1) ;


		}

	}  catch (SQLException ex) {
		System.out.println("error code : " + ex.getErrorCode());
		System.out.println("error message : " + ex.getMessage());
	} catch (Exception e) {
		e.printStackTrace();
	}
	return entrada;


}

public synchronized void insert_on_facebook_table(int idea, String post_idea) throws RemoteException{ //muahaha
	Statement stmt;
	
	try {		       
		stmt =  connection.createStatement();
		  stmt.executeQuery("insert into facebook (idea_key,post_id) values ("+idea+",'"+post_idea+"')");
		//rs.next();
		

	}  catch (SQLException ex) {
		System.out.println("error code : " + ex.getErrorCode());
		System.out.println("error message : " + ex.getMessage());
	} catch (Exception e) {
		e.printStackTrace();
	}
	System.out.println("chegou ao fim da função");

	
}

public synchronized  String get_idea_key_from_facebook (int idea_key) throws RemoteException{
	Statement stmt;
	ResultSet rs ;
	String temp = null;

	try {		       
		stmt =  connection.createStatement();
		rs=stmt.executeQuery("SELECT post_id from facebook where idea_key="+idea_key);
		rs.next();

			temp= rs.getString(1) ;
		
		if(temp==null)	{
			temp="bananas";
		}
		
		else if(temp.length()<2){
			
			temp="bananas";
		}

		

	}  catch (SQLException ex) {
		System.out.println("error code : " + ex.getErrorCode());
		System.out.println("error message : " + ex.getMessage());
	} catch (Exception e) {
		e.printStackTrace();
	}
	return temp;


}


public synchronized  void delete_deleters (int idea_key) throws RemoteException{
	Statement stmt;
	

	try {		       
		stmt =  connection.createStatement();
		stmt.executeQuery("Delete from facebook where idea_key="+idea_key);
	

	}  catch (SQLException ex) {
		System.out.println("error code : " + ex.getErrorCode());
		System.out.println("error message : " + ex.getMessage());
	} catch (Exception e) {
		e.printStackTrace();
	}


}

}
