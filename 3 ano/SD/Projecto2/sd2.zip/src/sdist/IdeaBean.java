package sdist;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;

import quicktime.std.movies.media.UserData;

public class IdeaBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Bd bd;
	private ArrayList<Idea> array_total_idea;

	private ArrayList<Idea> array_search_idea;
	private ArrayList<Idea> array_topic_idea;
	private ArrayList<Idea> array_porfolio_idea; // nao tenho certeza se funcionam. Funcoes antigos
	private ArrayList<Idea> array_watchlist_idea; 
	private ArrayList<Idea> array_fully_owened_idea; // nao tenho certeza se funcionam. Funcoes antigos
	private Idea idea_escolhida;
	private String string_imprimir;




	public IdeaBean() {
		super();
		bd=LoginServlet.bd;
		
	}
	//-----------------IDEAS TODAS-----------------//
	public ArrayList<Idea> getArray_total_idea() {
		setArray_total_idea();
		return array_total_idea;
	}
	public void setArray_total_idea() {
		try {
			array_total_idea=bd.getAllIdeas();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//-----------------IDEAS POR PROCURA NOME-----------------//
	public ArrayList<Idea> getArray_search_idea() {
	//	setArray_search_idea(palavra);
		return array_search_idea;
	}
	public void setArray_search_idea(String palavra) {
		try {
			array_search_idea = bd.getIdeasByName(palavra);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//-----------------IDEAS POR TOPICO-----------------//
	public ArrayList<Idea> getArray_topic_idea() {
		//setArray_topic_idea( topic_key);
		return array_topic_idea;
	}
	public void setArray_topic_idea(int topic_key) {
		try {
			array_topic_idea = bd.getIdeas(topic_key);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//-----------------IDEAS PORTFOLIO-----------------//
	public ArrayList<Idea> getArray_porfolio_idea() {
		return array_porfolio_idea;
	}
	public void setArray_porfolio_idea(String user) {
		try {
			array_porfolio_idea =bd.getPartialownIdeas(user);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//-----------------IDEAS WATCHLIST-----------------//
	public ArrayList<Idea> getArray_watchlist_idea() {

		//setArray_watchlist_idea( user);
		return array_watchlist_idea;
	}
	public void setArray_watchlist_idea(String user) {

		try {
			array_watchlist_idea = bd.get_watched_ideas(user);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//-----------------IDEAS COM PROPRIADADE TOTAL-----------------//
	public ArrayList<Idea> getArray_fully_owened_idea() {
		//setArray_fully_owened_idea( user);
		return array_fully_owened_idea;
	}
	public void setArray_fully_owened_idea(String user) {
		try {
			array_fully_owened_idea = bd.getfullyownIdeas(user);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void IdeasString(String modo, String chave){
		ArrayList<Idea> tipo_array = null;
		string_imprimir="";
		int i;
		String tipo=modo;
		if(tipo=="array_total_idea"){
			System.out.println(array_total_idea);
			setArray_total_idea();
			tipo_array=array_total_idea;
		}
		else if(tipo=="array_search_idea"){
			System.out.println(array_search_idea);
			setArray_search_idea(chave);
			tipo_array=array_search_idea;

		}

		else if(tipo=="array_porfolio_idea"){
			setArray_porfolio_idea(chave);
			tipo_array=array_porfolio_idea;
		}
		else if(tipo=="array_watchlist_idea"){
			setArray_watchlist_idea( chave);
			tipo_array=array_watchlist_idea;

		}
		else if(tipo=="array_fully_owened_idea"){
			setArray_fully_owened_idea(chave);
			tipo_array=array_fully_owened_idea;

		}
		else if(tipo=="array_topic_idea"){
			setArray_topic_idea(Integer.parseInt(chave));
			tipo_array=array_topic_idea;

		}
		for(i=0;i<tipo_array.size();i++){

			string_imprimir=string_imprimir+"<p>"+(i+1)+"--"+tipo_array.get(i).getTexto()+"</p>";
		}
	}
	public Idea getIdea_escolhida() {
		return idea_escolhida;
	}
	public String textogetIdea_escolhida() {
		return idea_escolhida.getTexto();
	}
	public void setIdea_escolhida(String tipo, int i) {
		
		if(tipo.equals("array_total_idea")){
		
			idea_escolhida=array_total_idea.get(i);
		}
		else if(tipo.equals("array_search_idea")){
			
			idea_escolhida=array_topic_idea.get(i);
		}

		else if(tipo.equals("array_porfolio_idea")){
			
			idea_escolhida=array_porfolio_idea.get(i);
		}
		else if(tipo.equals("array_watchlist_idea")){
			
			idea_escolhida=array_watchlist_idea.get(i);
		}
		else if(tipo.equals("array_fully_owened_idea")){
			
			idea_escolhida=array_fully_owened_idea.get(i);
		}
		else if(tipo.equals("array_topic_idea")){
			
			idea_escolhida=array_topic_idea.get(i);
		}
		
		
		 
	}
	public float owened_shares(){
		
		
		try {
			return  bd.getShares( LoginServlet.userData.getUserName(),idea_escolhida.getIdea_key());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public float pre�o_mais_baixo(){
		
		try {
			return bd.pre�o_mais_baixo( idea_escolhida.getIdea_key());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	

	public String string_imprimir(){
		return string_imprimir;
	}


}