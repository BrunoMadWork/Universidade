package sdist;

public class PossibleBuy {

	private int idea_key;
	private float preço;
	private float n_acções;
	public PossibleBuy(int idea_key, float preço, float n_acções) {
		super();
		this.idea_key = idea_key;
		this.preço = preço;
		this.n_acções = n_acções;
	}
	public void setIdea_key(int idea_key) {
		this.idea_key = idea_key;
	}
	public void setPreço(float preço) {
		this.preço = preço;
	}
	public void setN_acções(float n_acções) {
		this.n_acções = n_acções;
	}
	
}
