package sdist;

import java.io.Serializable;

public class StringStoricBean implements Serializable {
	String historico;

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}
}
