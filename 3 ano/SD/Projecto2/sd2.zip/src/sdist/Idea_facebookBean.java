package sdist;

import java.io.Serializable;

public class Idea_facebookBean implements Serializable {

	String texto_facebook;
	public Idea_facebookBean(){
		
	}
	public String getTexto_facebook() {
		return texto_facebook;
	}
	public void setTexto_facebook(String texto_facebook) {
		this.texto_facebook = texto_facebook;
	}
	
}
