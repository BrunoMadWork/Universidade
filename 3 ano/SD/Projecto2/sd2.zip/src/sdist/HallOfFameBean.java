package sdist;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class HallOfFameBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Idea> array_ideais;
	private Bd bd;
	
	public HallOfFameBean (){
		bd=LoginServlet.bd;
	}


	public ArrayList<Idea> getArray_ideais() {
		return array_ideais;
	}


	public void setArray_ideais() {
		try {
			array_ideais=bd.GetHallOffameIdeas();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	  //ArrayList<Entrada_historico> get_historico_by_idea(int idea_key) 

	
	public String Imprime_hall(){
		setArray_ideais();
		String temp="";
		int i,j;
		for(i=0;i<array_ideais.size();i++){
			String aux="";
			ArrayList<Entrada_historico> entrada = null;
			try {
				entrada = bd.get_historico_by_idea(array_ideais.get(i).getIdea_key());
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for(j=0;j<entrada.size();j++){
				aux=aux+"<p>"+entrada.get(j).printEntry() +"</p>";
			}
			temp=temp+"<p>"+array_ideais.get(i).getTexto() + "</p>"+aux;
		}
		return temp;

	}
}
