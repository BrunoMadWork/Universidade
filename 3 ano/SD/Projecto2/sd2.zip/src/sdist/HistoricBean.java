package sdist;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class HistoricBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ArrayList<Entrada_historico> array_historico;
	Bd bd=LoginServlet.bd;

	public ArrayList<Entrada_historico> getArray_historico() {
		setArray_historico();
		return array_historico;
	}

	public void setArray_historico() {
		try {
			array_historico =bd.get_historico();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String stringHistorico(){
		setArray_historico();
		String temp="";
		int i;
		System.out.println(array_historico.size());
		for(i=0;i<array_historico.size();i++){
			temp=temp+"<p>"+ array_historico.get(i).printEntry()+"</p>";
		}
		return temp;
	}
	
	
}
