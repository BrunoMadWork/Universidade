package sdist;

import org.apache.catalina.websocket.WebSocketServlet;
import org.apache.catalina.websocket.MessageInbound;
import org.apache.catalina.websocket.StreamInbound;
import org.apache.catalina.websocket.WsOutbound;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;
import java.io.IOException;

public class ChatWebSocketServlet extends WebSocketServlet  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final AtomicInteger sequence = new AtomicInteger(0);
	private final Set<ChatMessageInbound> connections =
			new CopyOnWriteArraySet<ChatMessageInbound>();

	public ChatWebSocketServlet(){

		/* try {
			notificacoes=new Notificacoes_implementation(this);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
	protected StreamInbound createWebSocketInbound(String subProtocol,
			HttpServletRequest request) {
		return new ChatMessageInbound(sequence.incrementAndGet());
	}

	public final class ChatMessageInbound extends MessageInbound { //private

		Notificacoes notificacoes;
		private ChatMessageInbound(int id) {
			//this.nickname = "Client" + id;
			try {
				notificacoes=new Notificacoes_implementation(this);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//this.nickname = LoginServlet.userData.getUserName();
			//System.out.println(this.nickname);

		}

		protected void onOpen(WsOutbound outbound) {
			connections.add(this);
		}

		protected void onClose(int status) {
			connections.remove(this);
		}

		public void onTextMessage(CharBuffer message) throws IOException {
			// never trust the client
			//meter aqui e mudar as merdas
			String filteredMessage = filter(message.toString());
			//broadcast("&lt;" + nickname + "&gt; " + filteredMessage);
			//if(!array_users.contains(filteredMessage)){
			//array_users.add(filteredMessage);
			//System.out.println("Entrou novo user");
		}


	

	/*private void broadcast(String message) { // send message to all
			for (ChatMessageInbound connection : connections) {
				try {
					CharBuffer buffer = CharBuffer.wrap(message);
					connection.getWsOutbound().writeTextMessage(buffer);
				} catch (IOException ignore) {}
			}
		}
	 */
	public void  broadcast(String message) { // send message to all
		for (ChatMessageInbound connection : connections) {
			try {
				System.out.println(message);
				CharBuffer buffer = CharBuffer.wrap(message);
				//int i;
				//	System.out.println("O tamanho é "+array_users.size());
				//for(i=0;i<array_users.size();i++){
				//if(LoginServlet.userData.getUserName().equals(array_users.get(i)))
				//System.out.println(" Mandou para "+nome);
				connection.getWsOutbound().writeTextMessage(buffer);
			}
			catch (IOException ignore) {}
		}
	}
	public String filter(String message) {
		if (message == null)
			return (null);
		// filter characters that are sensitive in HTML
		char content[] = new char[message.length()];
		message.getChars(0, message.length(), content, 0);
		StringBuilder result = new StringBuilder(content.length + 50);
		for (int i = 0; i < content.length; i++) {
			switch (content[i]) {
			case '<':
				result.append("&lt;");
				break;
			case '>':
				result.append("&gt;");
				break;
			case '&':
				result.append("&amp;");
				break;
			case '"':
				result.append("&quot;");
				break;
			default:
				result.append(content[i]);
			}
		}
		return (result.toString());
	}

	protected void onBinaryMessage(ByteBuffer message) throws IOException {
		throw new UnsupportedOperationException("Binary messages not supported.");
	}
}
}
/*
	public ArrayList<String> getArray_users() {
		return array_users;
	}
	public void setArray_users(ArrayList<String> array_users) {
		this.array_users = array_users;
	}

	}

 */
