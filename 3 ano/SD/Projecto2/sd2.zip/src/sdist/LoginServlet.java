/**
 * 
 */

package sdist;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet
{
	private static final long serialVersionUID = -8608034654794572382L;
	HttpSession session;
	static Bd bd;
	private Login_Bean login_bean;
	HistoricBean historic_bean;
	StringStoricBean stringstoricbean;
	ViewChoiceBean viewchoicebean;
	public  IdeaBean ideabean;
	private TopicBean topicbean;
	public static User userData;
	HallOfFameBean halloffamebean;
	private ChatWebSocketServlet notificacoes;
	private Idea_facebookBean idea_facebookbean;
	
	public void init() throws ServletException
	{ //inicia��o do rmi
		//System.getProperties().put("java.security.policy","java.policy");
		//System.setSecurityManager(new RMISecurityManager());


		try {
			try {
				bd = (Bd) Naming.lookup("rmi://localhost:7000/Bd");
			} catch (RemoteException e) {
				throw new ServletException(e);	
			} catch (NotBoundException e) {
				throw new ServletException(e);
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			throw new ServletException(e);
		}

		login_bean=new Login_Bean();
		historic_bean=new HistoricBean() ;
		stringstoricbean= new StringStoricBean();
		viewchoicebean= new ViewChoiceBean();
		topicbean=new TopicBean();
		ideabean=new IdeaBean();
		halloffamebean=new HallOfFameBean();
		String searchType=null;
		 idea_facebookbean=new Idea_facebookBean();
		


		/*
		try {
			registry = LocateRegistry.getRegistry(7000);
		} catch (RemoteException e) {
			throw new ServletException(e);	

		}
		try {
		 bd = (Bd) registry.lookup("Bd"); //da erro
		// bd = (Bd) registry.lookup(  ); //da erro

		} catch (AccessException e) {
			throw new ServletException(e);	
		} catch (RemoteException e) {
			throw new ServletException(e);	
		} catch (NotBoundException e) {
			throw new ServletException(e);	

		}
		 */
	}
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		
		RequestDispatcher dispatcher = null;
		session = request.getSession(true);
		session.setAttribute("viewchoicebean", viewchoicebean);
		session.setAttribute("topicbean", topicbean);
		session.setAttribute("ideabean", ideabean);
		session.setAttribute("halloffamebean", halloffamebean);
		session.setAttribute("idea_facebookbean", idea_facebookbean);



		
		
		if(request.getParameter("loginbutton") != null){

			String user = request.getParameter("userName");
			String pass = request.getParameter("passWord");
			System.out.println(user);
			System.out.println(pass);
			System.out.println(login_bean.getArray_nomes(bd).getArray());
			System.out.println(login_bean.get_password(bd, user));

			if(login_bean.getArray_nomes(bd).getArray().contains(user) && pass.equals(login_bean.get_password(bd, user))){
				System.out.println("É true");
				
				userData = new User();
				userData.setUserName(user);
				userData.setIsRoot(login_bean.getArray_nomes(bd).getArray_ints().get(login_bean.getArray_nomes(bd).getArray().indexOf(user)));
				session.setAttribute("user", userData);
				session.setAttribute("viewchoicebean", viewchoicebean);
				session.setAttribute("topicbean", topicbean);
				session.setAttribute("ideabean", ideabean);
				session.setAttribute("halloffamebean", halloffamebean);
				session.setAttribute("idea_facebookbean", idea_facebookbean);


				
				dispatcher = request.getRequestDispatcher("/userinfo.jsp");
			}
			else
			{
				dispatcher = request.getRequestDispatcher("/invaliduser.html");
			}
		}

		else if(request.getParameter("registerbutton") != null){

			String user = request.getParameter("userName2");
			String pass = request.getParameter("passWord2");

			System.out.println(user);
			System.out.println(pass);

			if(user!=null&&pass!=null&&!(user.equals(""))&&!(pass.equals(""))&&!(login_bean.getArray_nomes(bd).getArray().contains(user))){
				login_bean.insert_user(user, pass, bd);
				System.out.println("I was here");
				dispatcher = request.getRequestDispatcher("/NewUserValidated.jsp");
			}
			else{
				dispatcher = request.getRequestDispatcher("/invaliduser.html");

			}

		}
		




		else if(request.getParameter("BTNcreate") != null){
			System.out.println("Ca estou eu!");
			dispatcher = request.getRequestDispatcher("/InsertIdea.jsp");
		}
		/*else if(request.getParameter("BTNdelete") != null){
			System.out.println("Ca estou eu!");
		}*/
		else if(request.getParameter("BTNsearch") != null){
			dispatcher = request.getRequestDispatcher("/SeachIdea.jsp");
			System.out.println("Ca estou eu!");
		}
		/*else if(request.getParameter("BTNsetPrice") != null){
			System.out.println("Ca estou eu!");
		}*/
		
		else if(request.getParameter("BTNhall") != null){
			//halloffamebean.setArray_ideais();
			System.out.println("hall of fame");
			dispatcher = request.getRequestDispatcher("/ShowHallOfFame.jsp");

			
		}
		
		else if(request.getParameter("BTNbuy") != null){
			System.out.println("Ca estou eu!");
		}
		else if(request.getParameter("BTNhistory") != null){
			System.out.println("Ca estou eu!");

			ArrayList<Entrada_historico> array_historico	=historic_bean.getArray_historico();

			String stp="";
			int i;
			for(i=0;i<array_historico.size();i++){
				stp= stp.concat(array_historico.get(i).printEntry());
			}
			if(stp!=null){
				stringstoricbean.setHistorico(stp);
			}
			dispatcher = request.getRequestDispatcher("/history.jsp");
		}	

		
		else if(request.getParameter("BTNlogout") != null){
			System.out.println("Ca estou eu!");
			dispatcher = request.getRequestDispatcher("/userlogin.html");

		}
		else if(request.getParameter("insertIdeaBTN") != null){
			System.out.println("Ca estou eu!");
			ArrayList<String> hashtag;


			String stringTopicos=request.getParameter("Topicos_insert");
			String texto=request.getParameter("Ideas_insert");
			String  ficheiro=request.getParameter("File_insert");
			int numero_acções_investir=Integer.parseInt(request.getParameter("Actions_insert"));
			String file=request.getParameter("File_insert");
			hashtag=(new Elementtokenizer()).getHash(stringTopicos);
			if(!(numero_acções_investir>bd.get_creditos(userData.getUserName()))){
				if(texto!=null&&texto!=""&&hashtag!=null){
					if(file==""||file==null){
						bd.put_all_things(userData.getUserName(), hashtag, 1000000,0, ((float)numero_acções_investir)/100000, texto);
						bd.retirar_saldo(userData.getUserName(), numero_acções_investir);
						idea_facebookbean.setTexto_facebook(texto);

					}
					else{
						System.out.println(file);
						File f=new File(file);
						long tamanho =f.length();
						FileInputStream	is = new FileInputStream(f);
						bd.put_all_things(userData.getUserName(), hashtag, 1000000,0, ((float)numero_acções_investir)/100000 ,texto,file,tamanho,is);
						bd.retirar_saldo(userData.getUserName(), numero_acções_investir);
					}
					dispatcher = request.getRequestDispatcher("/IdeaSucess.jsp");
				}

				else{


					dispatcher = request.getRequestDispatcher("/InsertIdea.jsp");

				}
			}
		}
		else if(request.getParameter("SubmitProcura") != null){
			String escolha=request.getParameter("search_choice");
			System.out.println(escolha);
			String texto=request.getParameter("formularioProcura");
			if(escolha.equals("array_total_idea")){
				viewchoicebean.setModoVer("array_total_idea");
				ideabean.setArray_total_idea();
				ideabean.IdeasString("array_total_idea",null);
				
				dispatcher = request.getRequestDispatcher("/Searchresults.jsp");
			}
			else if(escolha.equals("array_search_idea")){
				viewchoicebean.setModoVer("array_search_idea");
				ideabean.setArray_search_idea(texto);
				ideabean.IdeasString("array_search_idea",texto);
				
				dispatcher = request.getRequestDispatcher("/Searchresults.jsp");

			}
			else if(escolha.equals("array_topic_idea")){
				viewchoicebean.setModoVer("array_topic_idea");
				topicbean.setArray_topicos();
				dispatcher = request.getRequestDispatcher("/choseTopic.jsp");

			}
			else if(escolha.equals("array_porfolio_idea")){
				viewchoicebean.setModoVer("array_porfolio_idea");
				ideabean.setArray_porfolio_idea(texto);
				ideabean.IdeasString("array_porfolio_idea",texto);
				dispatcher = request.getRequestDispatcher("/Searchresults.jsp");
			}
			else if(escolha.equals("array_watchlist_idea")){
				viewchoicebean.setModoVer("array_watchlist_idea");
				ideabean.setArray_watchlist_idea(texto);
				ideabean.IdeasString("array_watchlist_idea",userData.getUserName());
				dispatcher = request.getRequestDispatcher("/Searchresults.jsp");

			}
			else if(escolha.equals("array_fully_owened_idea")){
				viewchoicebean.setModoVer("array_fully_owened_idea");
				ideabean.setArray_fully_owened_idea(texto);
				ideabean.IdeasString("array_fully_owened_idea",userData.getUserName());
				dispatcher = request.getRequestDispatcher("/Searchresults.jsp");

			}
		}
		else if(request.getParameter("ChoiceTopic") != null){
			System.out.println("Ca estou eu!");
			String topico_escolhido = request.getParameter("TopicChosebutton");
			topicbean.setTopico_escolhido(Integer.parseInt(topico_escolhido)-1);
			viewchoicebean.setModoVer("array_topic_idea");
			ideabean.setArray_topic_idea(Integer.parseInt(topico_escolhido)-1);
			ideabean.IdeasString("array_topic_idea",Integer.toString(topicbean.getTopico_escolhido().getTopic_key())); //atencao a isto
			dispatcher = request.getRequestDispatcher("/Searchresults.jsp");
		}
		
		else if(request.getParameter("Backmenu") != null){
			dispatcher = request.getRequestDispatcher("/userlogin.html");
		}
		
		else if(request.getParameter("ChoooseIdea") != null){
			System.out.println("WHY I'm still sober?!");
			int indice=(Integer.parseInt(request.getParameter("ideaChoseform"))-1);
			System.out.println(indice);
			ideabean.setIdea_escolhida(viewchoicebean.getModoVer(),indice);
			dispatcher = request.getRequestDispatcher("/choseAfterChoseIdea.jsp");


		}
		
		//botoes das op��es
		
		else if(request.getParameter("buy_idea_radio") != null){
			
			dispatcher = request.getRequestDispatcher("/BuyIdea.jsp");

		}
		else if(request.getParameter("delete_idea_radio") != null){
			bd.deleteIdeas(ideabean.getIdea_escolhida(),userData.getUserName());
			dispatcher = request.getRequestDispatcher("/SucessfullDelete.jsp");

		}
		else if(request.getParameter("set_selling_price_radio") != null){
			
			dispatcher = request.getRequestDispatcher("/setPrice.jsp");

		}
		else if(request.getParameter("takeover_the_over_radio") != null){
			if(userData.getIsRoot()==1){
				bd.Takeover_the_root(userData.getUserName(), ideabean.getIdea_escolhida());
				dispatcher = request.getRequestDispatcher("/RootTaken.jsp"); //sucesso

			}
			else{
				dispatcher = request.getRequestDispatcher("/RootTakeoverFailed.jsp"); //azar...n�o � root
			}
		}
		else if(request.getParameter("wathclist_radio") != null){
			
			bd.add_to_wacthlist(userData.getUserName(), ideabean.getIdea_escolhida());
			dispatcher = request.getRequestDispatcher("/Idea_na_watchlist.jsp");

		}
		
		
		

		else if(request.getParameter("ChoiceBuyIdea") != null){ //se der erro mandar para a pagina again, sen�o mandar para uma de sucesso
			Float numero_acções=Float.valueOf(request.getParameter("Numero_acções_compra"));
			Float preço_maximo=Float.valueOf(request.getParameter("preço_maximo_acção_compra"));
			if(preço_maximo!=null&&preço_maximo!=0&&numero_acções!=null&&numero_acções!=0){
				bd.new_pedido(userData.getUserName(),ideabean.getIdea_escolhida(),preço_maximo, numero_acções);
				bd.Transaction_handler();
				//aqui que se vai por as cenas para as notificaçoes
				
				
				dispatcher = request.getRequestDispatcher("/BuySucess.jsp");

			}
			else{
				dispatcher = request.getRequestDispatcher("/BuyNotSucess.jsp");

			}
		}
		
		
		else if(request.getParameter("ChoiceNewSetPrice") != null){
			float new_price=Float.valueOf(request.getParameter("New_price_set"));
			bd.alterar_preço(new_price, ideabean.getIdea_escolhida().getIdea_key(), userData.getUserName());
			dispatcher = request.getRequestDispatcher("/SucessPriceChange.jsp");

		}
		else if((userData.getUserName().equals(""))||(userData.getUserName()==null)){
			dispatcher = request.getRequestDispatcher("/userlogin.html"); //sucesso

		}
		

		dispatcher.forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		doGet(request, response);
	}
	public Login_Bean getLogin_bean() {
		return login_bean;
	}
	public void setLogin_bean(Login_Bean login_bean) {
		this.login_bean = login_bean;
	}

}
