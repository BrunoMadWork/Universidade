package sdist;

import java.io.Serializable;

public class ViewChoiceBean implements Serializable {

	String modoVer;

	public String getModoVer() {
		return modoVer;
	}

	public void setModoVer(String modoVer) {
		this.modoVer = modoVer;
	}
	
}
