package sdist;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class TopicBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Topico topico_escolhido;
	private ArrayList<Topico> array_topicos;
	private Bd bd;
	
	
	
	
	public TopicBean() {
		bd=LoginServlet.bd;
	}

	public ArrayList<Topico> getArray_topicos() {
		setArray_topicos();
		return array_topicos;
	}

	public void setArray_topicos() {
		
		try {
			array_topicos=bd.getTopicos();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public String TopicString(){
		 setArray_topicos();
		ArrayList<Topico> array = array_topicos;
		String temp="";
		int i;
		
		for(i=0;i<array.size();i++){

			temp=temp+"<p>"+(i+1)+"--"+array.get(i).getTexto()+"</p>";
		}
		return temp;
	}

	public Topico getTopico_escolhido() {
		return topico_escolhido;
	}

	public void setTopico_escolhido(int indice) {
		setArray_topicos();
		topico_escolhido = array_topicos.get(indice);
		
	}

}
