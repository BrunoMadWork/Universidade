//////////////////////////////////////////////////////////////////////////////
#ifndef _FUNCTIONSH_ 
#define _FUNCTIONSH_
#include "header.h"
//////////////////////////////////////////////////////////////////////////////
is_Program* createProgram(char*, is_ListDeclaration*);
is_ListDeclaration* insert_BodyNull();
is_ListDeclaration* insert_BodyVarDecl(is_ListDeclaration*, is_VarDecl*);
is_VarDecl* insert_isVarDecl(varType, char*, is_ListVar*);
is_ListVar* insert_isListVarNull();
is_ListVar* insert_isListVarReal(char*, is_ListVar*);
is_ListDeclaration* insert_BodyMethod(is_ListDeclaration*, is_MethodDecl*);
is_MethodDecl* insert_isMethodDecl(
	varType, char*, is_OptionalFormalParams*, 
	is_MultVarDecl*, is_MultStatement*
);
is_OptionalFormalParams* insert_FormalParamsNormal(
	varType, char*, is_OptionalFormalParams*
);
is_OptionalFormalParams* create_FormalParamsStringed(char*);
is_OptionalFormalParams* insert_FormalParamsNull();
is_OptionalFormalParams* insert_ListFormalParamsNormal(
	varType , char* , is_OptionalFormalParams* 
);
is_MultVarDecl* insert_MultVarDeclNull();
is_MultVarDecl* insert_MultVarDecl(is_MultVarDecl*, is_VarDecl*);
is_MultStatement* create_MultStatNull();
is_MultStatement* insert_MultStat_Stat(is_MultStatement*, is_Statement*);
is_Statement* create_MultStat(is_MultStatement*);
is_MultStatement* create_MultStatBodyNull();
is_MultStatement* insert_MultStatBody_Stat(is_MultStatement* , is_Statement* );
is_Statement* create_Return(is_Expression*);
void simplifyStatement(is_Statement* );
is_MultExpression* create_MultExpressionNull();
is_MultExpression* insert_MultExpression_Expression(
	is_MultExpression*, is_Expression* 
);
is_MultExpression* insert_Expression_MultExpression(
	is_Expression*, is_MultExpression* 
);
is_Expression* create_ExpressionNull();
is_Expression* create_Expression_Expr1(Expr1*);
is_Statement* create_IfThenElse(is_Expression* , is_Statement* , is_Statement* );
is_Statement* create_While(is_Expression* , is_Statement* );
is_Statement* create_Print(is_Expression* );
is_Statement* create_Assignment(char*, is_Expression*);
is_Statement* create_ArrayAssignment(char*, is_Expression*, is_Expression*);
is_Expr1* create_CurveExpression(is_Expression*);
is_Expr1* create_DotlenExpr(is_Expression* );
is_Expr1* create_ParseintIDExpression(char* , is_Expression* );
is_Expression* create_NewArray(varType, is_Expression*);
is_Expr1* create_GetArrayAcess(is_Expr1*, is_Expression*);
is_Expression* create_MultiOperator(is_Expression* , operType , is_Expression* );
is_Expression* create_UniOperator(operType , is_Expression* );
is_Expr1* create_MethodCall(char*, is_MultExpression*);
is_Expr1* create_Boolean(char*);
is_Expr1* create_Int(char* );
is_Expr1* create_ID(char* );
//////////////////////////////////////////////////////////////////////////////
#endif
//////////////////////////////////////////////////////////////////////////////
