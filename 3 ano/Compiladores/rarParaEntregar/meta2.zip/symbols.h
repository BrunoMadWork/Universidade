//////////////////////////////////////////////////////////////////////////////
#ifndef _SYMBOLSH_ 
#define _SYMBOLSH_
#include <stdlib.h>
#include "header.h"
#define NSYMS 1000
//////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------		
typedef struct _SymVar {
	char *name;
	varType type;
	union {
		int iValue;
		char bValue;
		int* iArrValue;
		char* bArrValue;
	} value;
} SymVar;
//-----------------------------------------------------------------------------		
typedef struct _SymMethod {
	char *name;
	varType returnType;
	SymVar* paramTab[NSYMS];
	SymVar* varTab[NSYMS];
	is_MultStatement* iMS;
} SymMethod;
//-----------------------------------------------------------------------------
typedef struct _SymGeneric {
	varOrMethod type;
	union {
		SymVar* staticVar;
		SymMethod* method;
	} value;
} SymGeneric;

//-----------------------------------------------------------------------------
SymVar** symVarLook(SymVar* [], char* );
SymMethod** symMethodLook(SymMethod* [], char* );
void symTabPrint(SymGeneric []);
void symVarPrint(SymVar*[]);
void symParamVarPrint(SymVar* []);
void symMethodPrint(SymMethod* []);
char* methodTypeReturn(varType );
void insert_SymVarDecl(SymVar* [], is_VarDecl* );
void insert_IntSymbol(SymVar** , char* );
void insert_BooleanSymbol(SymVar** , char* );
void insert_IntArrSymbol(SymVar** , char* ); 
void insert_BooleanArrSymbol(SymVar** , char* );
void insert_Method(SymMethod* [], is_MethodDecl* );
int isSameMethod(SymMethod* , is_MethodDecl* );
int verifyMultStatement(is_MultStatement* , SymVar* [], SymVar* [], varType );
int verifyStatement(is_Statement* , SymVar* [], SymVar* [], varType );
varType getVarType(char* , SymVar* [], SymVar* []);
char* toStringType(varType );
char* toStringOperator(operType );
char* toStringStat(statementType );
int isArrayType(varType );
int getArrayType(varType );
varType getTypeExpression(is_Expression* , SymVar* [],  SymVar* []);
varType getTypeExpr1(is_Expr1* , SymVar* [], SymVar* []);
varType getMethodType(is_MethodCall* , SymVar* [], SymVar* []);
void insert_FormalVars(SymVar* [], is_OptionalFormalParams* );
void insert_MethodVars(SymVar* [], SymVar* [], varType , char* );
//////////////////////////////////////////////////////////////////////////////
#endif
