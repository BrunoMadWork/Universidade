//////////////////////////////////////////////////////////////////////////////
#include "header.h"
//////////////////////////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------
is_Program* createProgram(char* id, is_ListDeclaration* list) {
	is_Program* iP = (is_Program*)malloc(sizeof(is_Program));
	iP->nome = id;
	iP->lista = list;
	return iP;
}
//-----------------------------------------------------------------------------
is_ListDeclaration* insert_BodyNull() {
	is_ListDeclaration* node = (is_ListDeclaration*)malloc(sizeof(is_ListDeclaration));
	node->b = NULL;
	node->next = NULL;
	return node;
}
//-----------------------------------------------------------------------------
is_ListDeclaration* insert_BodyVarDecl(is_ListDeclaration* list, is_VarDecl* iVD) {
	is_ListDeclaration* node = (is_ListDeclaration*) malloc(sizeof(is_ListDeclaration));
	is_ListDeclaration* aux;
	for(aux = list; aux->next; aux = aux->next)
		;
	aux->next = node;			
	node->next = NULL;
	is_Body* body = (is_Body*)malloc(sizeof(is_Body));
	body->vM = is_VAR;
	body->data_declaration.VarDecl = (is_VarDecl*) iVD;
	node->b = body;
	return list;
}
//-----------------------------------------------------------------------------
is_VarDecl* insert_isVarDecl(varType vType, char* id, is_ListVar* list) {
	is_VarDecl* varDecl = (is_VarDecl*) malloc(sizeof(is_VarDecl));
	varDecl->type = vType;
	is_ListVar* nodeFirst = (is_ListVar*)malloc(sizeof(is_ListVar));
	nodeFirst->nomeVar = id;
	nodeFirst->next = list;
	varDecl->listaVars = nodeFirst;
	return varDecl;
}
//-----------------------------------------------------------------------------
is_ListVar* insert_isListVarNull() {
	is_ListVar* node= (is_ListVar*)malloc(sizeof(is_ListVar));
	node->nomeVar = NULL;
	node->next = NULL;
	return node;
}
//-----------------------------------------------------------------------------
is_ListVar* insert_isListVarReal(char* id, is_ListVar* list) {
	is_ListVar* firstNode= (is_ListVar*)malloc(sizeof(is_ListVar));
	firstNode->nomeVar = id;
	is_ListVar* aux;
	firstNode->next = list;
	return firstNode;
}
//-----------------------------------------------------------------------------
is_ListDeclaration* insert_BodyMethod(is_ListDeclaration* list, is_MethodDecl* iMD) {
	is_ListDeclaration* node = (is_ListDeclaration*)malloc(sizeof(is_ListDeclaration));
	is_ListDeclaration* aux;
	for (aux = list; aux->next; aux = aux->next)
		;
	aux->next = node;			
	node->next = NULL;
	is_Body* body = (is_Body*)malloc(sizeof(is_Body));
	body->vM = is_METHOD;
	body->data_declaration.VarDecl = (is_VarDecl*) iMD;
	node->b = body;
	return list;
}
//-----------------------------------------------------------------------------
is_MethodDecl* insert_isMethodDecl(varType type, char* id,
	is_OptionalFormalParams* oFP, is_MultVarDecl* iMVD, is_MultStatement* iMS) {
	is_MethodDecl* iMD = (is_MethodDecl*)malloc(sizeof(is_MethodDecl));
	iMD->type = type;
	iMD->nome = id;
	iMD->iOFP = oFP;
	iMD->iMVD = iMVD;
	iMD->iMS = iMS;
	return iMD;
}
//-----------------------------------------------------------------------------
is_OptionalFormalParams* create_FormalParamsStringed(char* id) {
	is_OptionalFormalParams* first = insert_FormalParamsNull();
	is_OptionalFormalParams* str = (is_OptionalFormalParams*)malloc(sizeof(is_OptionalFormalParams));	
	str->type = STRING_ARR;
	str->nome = id;
	str->next = NULL;
	first->next = str;
	return first;
}
//-----------------------------------------------------------------------------
is_OptionalFormalParams* insert_FormalParamsNormal(varType type, char* id, is_OptionalFormalParams* lista) {
	is_OptionalFormalParams* first = (is_OptionalFormalParams*)malloc(sizeof(is_OptionalFormalParams));	
	first->type = type;
	first->nome = id;
	first->next = lista->next;
	lista->next = first;
	//printf("ID:%s\n", first->nome);
	return lista;
}
//-----------------------------------------------------------------------------
is_OptionalFormalParams* insert_ListFormalParamsNormal(varType type, char* id, is_OptionalFormalParams* lista) {
	is_OptionalFormalParams* node = (is_OptionalFormalParams*)malloc(sizeof(is_OptionalFormalParams));	
	node->type = type;
	node->nome = id;
	is_OptionalFormalParams* aux;
	for(aux = lista; aux->next; aux = aux->next)
		;
	node->next = aux->next;
	aux->next = node;
	//printf("ID:%s\n", first->nome);
	return lista;
}
//-----------------------------------------------------------------------------
is_OptionalFormalParams* insert_FormalParamsNull() {
	is_OptionalFormalParams* iOFP = (is_OptionalFormalParams*)malloc(sizeof(is_OptionalFormalParams));
	iOFP->nome = NULL;
	return iOFP;
}
//-----------------------------------------------------------------------------
is_MultVarDecl* insert_MultVarDeclNull() {
	is_MultVarDecl* iMVD = (is_MultVarDecl*)malloc(sizeof(is_MultVarDecl));
	iMVD->varDecl = NULL;
	return iMVD;
}
//-----------------------------------------------------------------------------
is_MultVarDecl* insert_MultVarDecl(is_MultVarDecl* start, is_VarDecl* iVD) {
	is_MultVarDecl* node = (is_MultVarDecl*)malloc(sizeof(is_MultVarDecl));
	node->type = IS_MULT_FULL;
	node->varDecl = iVD;
	node->next = NULL;
	is_MultVarDecl* aux;
	for (aux = start; aux->next; aux = aux->next)
		;
	aux->next = node;
	return start;
}
//-----------------------------------------------------------------------------
is_MultStatement* create_MultStatBodyNull() {
	is_MultStatement* iMS = (is_MultStatement*)malloc(sizeof(is_MultStatement));
	iMS->type = IS_MULTBODY_FULL;
	iMS->next = NULL;
	iMS->iS = NULL;
	return iMS;
}
//-----------------------------------------------------------------------------
is_MultStatement* create_MultStatNull() {
	//printf("create_MultStat.-1\n");
	is_MultStatement* iMS = (is_MultStatement*)malloc(sizeof(is_MultStatement));
	iMS->type = IS_MULT_FULL;
	iMS->next = NULL;
	iMS->iS = NULL;
	return iMS;
}
//-----------------------------------------------------------------------------
int multStatLenght(is_MultStatement* start) {
	int n = 0;
	is_MultStatement* aux;
	for (aux = start; aux->next; aux = aux->next) n++;
	return n;	
}
//-----------------------------------------------------------------------------
is_Statement* createEmptyMultStat() {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	is_MultStatement* node = (is_MultStatement*)malloc(sizeof(is_MultStatement));
	node->next = NULL;
	node->type = IS_MULT_FULL;
	iS->data_declaration.iM = node;
	iS->type = STAT_MULT;
}
//-----------------------------------------------------------------------------
is_MultStatement* insert_MultStatBody_Stat(is_MultStatement* start, is_Statement* iS) {
	is_MultStatement* node = (is_MultStatement*)malloc(sizeof(is_MultStatement));	
	node->iS = iS;
	node->next = NULL;
	node->type = IS_MULTBODY_NULL;
	is_MultStatement* aux;
	for (aux = start; aux->next; aux= aux->next)
		;
	aux->next = node;
	return start;
}
//-----------------------------------------------------------------------------
is_MultStatement* insert_MultStat_Stat(is_MultStatement* start, is_Statement* iS) {

	//printf("insert_MultStat_Stat.0\n");
	//printStatement(iS);
	if (iS->type == STAT_MULT) {
		//printf("insert_MultStat_Stat.1\n");
		//printStatement(iS);
		is_MultStatement* mult = iS->data_declaration.iM;
		if (! mult->next) {
			//printf("insert_MultStat_Stat.1\n");
			return start;
		}
	}

	is_MultStatement* node = (is_MultStatement*)malloc(sizeof(is_MultStatement));	
	node->iS = iS;
	node->next = NULL;
	node->type = IS_MULT_FULL;
	is_MultStatement* aux;
	for (aux = start; aux->next; aux= aux->next)
		;
	aux->next = node;
	return start;
}
//-----------------------------------------------------------------------------
///Expressões///
is_Statement* create_MultStat(is_MultStatement* iMS) {
	/*if (iMS->type == IS_MULT_FULL) {	//0 elementos
		printf("create_MultStat.0\n");
		//printMultiStatement(iMS);
		return iMS->iS;
	}*/
	/*if (! iMS->next->next) {	//1 elemento
		printf("create_MultStat.1\n");
		printMultiStatement(iMS);
		//return iMS->next->iS;
	}*/
	//printf("Nulo %d\n", iMS->type);
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	iS->type = STAT_MULT;
	iS->data_declaration.iM = (is_MultStatement*)iMS;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
is_MultExpression* create_MultExpressionNull() {
	is_MultExpression* iME = (is_MultExpression*)malloc(sizeof(is_MultExpression));
	iME->next = NULL;
	return iME;
}
//-----------------------------------------------------------------------------
is_MultExpression* insert_MultExpression_Expression(is_MultExpression* start, is_Expression* iE) {
	is_MultExpression* node = (is_MultExpression*)malloc(sizeof(is_MultExpression));	
	node->iE = iE;
	node->next = NULL;
	is_MultExpression* aux;
	for (aux = start; aux->next; aux= aux->next)
		;
	aux->next = node;
	return start;
}
//-----------------------------------------------------------------------------
is_MultExpression* insert_Expression_MultExpression(is_Expression* iE, is_MultExpression* start) {
	is_MultExpression* node = (is_MultExpression*)malloc(sizeof(is_MultExpression));	
	node->iE = iE;
	node->next = start->next;
	start->next = node;
	return start;
}
//-----------------------------------------------------------------------------
is_Expression* create_ExpressionNull() {
	return NULL;
}
//-----------------------------------------------------------------------------
is_Expression* create_Expression_Expr1(is_Expr1* expr1) {
	is_Expression* iE = (is_Expression*)malloc(sizeof(is_Expression));
	iE->type = EXPR1;
	iE->data_declaration.expr1 = expr1;
	return iE;
}
//-----------------------------------------------------------------------------
is_Statement* create_IfThenElse(is_Expression* iE, is_Statement* iThenStat, is_Statement* iElseStat) {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	is_IfThenElse* iITE = (is_IfThenElse*)malloc(sizeof(is_IfThenElse));
	iS->type = STAT_IFTHENELSE;
	iS->data_declaration.iITE = iITE;
	iITE->iE = iE;
	iITE->iThenStat = iThenStat;
	iITE->iElseStat = iElseStat;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
void simplifyStatement(is_Statement* stm) {
	//printf("simplify.1\n");
	if (stm->type == STAT_MULT) {
		//printf("simplify.2\n");
		is_MultStatement* mult = stm->data_declaration.iM;
		if (! mult->next) {
			//printf("simplify.3\n");
			mult->type = IS_MULT_NULL;
		}
	}
}
//-----------------------------------------------------------------------------
/*void simplifyStatement(is_Statement* stm) {
	if (stm->type == STAT_MULT) {
		is_MultStatement* aux;
		for(aux = stm->iM; aux->iS == NULL; aux = aux->next->iS)
			if (stm->type == STAT_MULT) {
				is_MultStatement* mult = stm->data_declaration.iM;
				if (! mult->next) {
					mult->type = IS_MULT_NULL;
				}
			}
		}
}*/
//-----------------------------------------------------------------------------
is_Statement* create_While(is_Expression* iE, is_Statement* iWhileStat) {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	is_While* iW = (is_While*)malloc(sizeof(is_While));
	iS->type = STAT_WHILE;
	iS->data_declaration.iW = iW;
	iW->iE = iE;
	iW->iWhileStat = iWhileStat;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
is_Statement* create_Print(is_Expression* iE) {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	is_Print* iP = (is_Print*)malloc(sizeof(is_Print));
	iS->type = STAT_PRINT;
	iS->data_declaration.iP = iP;
	iP->iE = iE;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
is_Statement* create_Assignment(char* id, is_Expression* iE) {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	iS->type = STAT_ASSIGNMENT;
	is_Assignment* iA = (is_Assignment*)malloc(sizeof(is_Assignment));
	iS->data_declaration.iA = iA;
	iA->id = id;
	iA->iE = iE;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
is_Statement* create_ArrayAssignment(char* id, is_Expression* index, is_Expression* value) {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement));
	iS->type = STAT_ARRAY_ASSIGNMENT;
	is_ArrayAssignment* iAA = (is_ArrayAssignment*)malloc(sizeof(is_ArrayAssignment));
	iS->data_declaration.iAA = iAA;
	iAA->id = id;
	iAA->index = index; 
	iAA->value = value;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
is_Statement* create_Return(is_Expression* iE) {
	is_Statement* iS = (is_Statement*)malloc(sizeof(is_Statement)); 
	is_Return* iR = (is_Return*)malloc(sizeof(is_Return));
	iR->iE = iE;
	iS->type = STAT_RETURN;
	iS->data_declaration.iR = iR;
	//iS->next = NULL;
	return iS;
}
//-----------------------------------------------------------------------------
is_Expr1* create_CurveExpression(is_Expression* iE) {
	is_Expr1* iE1 = (is_Expr1*)malloc(sizeof(is_Expr1));
	iE1->type = CRV_EXPR;
	is_CurveExpression* iCE = (is_CurveExpression*)malloc(sizeof(is_CurveExpression));
	iE1->data_declaration.iCE = iCE;
	iCE->iE = iE;
	return iE1;
}
//-----------------------------------------------------------------------------
is_Expr1* create_DotlenExpr(is_Expression* iE) {
	is_Expr1* iE1 = (is_Expr1*)malloc(sizeof(is_Expr1));
	iE1->type = DOTLEN_EXPR;
	is_DotlenExpr* iDE = (is_DotlenExpr*)malloc(sizeof(is_DotlenExpr));
	iE1->data_declaration.iDE = iDE;
	iDE->iE = iE;
	return iE1;
}		
//-----------------------------------------------------------------------------
is_Expr1* create_ParseintIDExpression(char* id, is_Expression* iE) {
	is_Expr1* iE1 = (is_Expr1*)malloc(sizeof(is_Expr1));
	iE1->type = PARSEINT_ID_EXPR;
	is_ParseintIDExpression* iPIE = (is_ParseintIDExpression*)malloc(sizeof(is_ParseintIDExpression));
	iE1->data_declaration.iPIE = iPIE;
	iPIE->id = id;
	iPIE->iE = iE;
	return iE1;
}
//-----------------------------------------------------------------------------
is_Expression* create_NewArray(varType type, is_Expression* iExpr) {
	is_Expression* iE = (is_Expression*) malloc(sizeof(is_Expression));
	is_ExprNewArr* iENA = (is_ExprNewArr*) malloc(sizeof(is_ExprNewArr));
	iENA->type = type;
	iENA->iE = iExpr;
	iE->data_declaration.iENA = iENA;
	iE->type = EXPR_NEW_ARR;
	return iE;
}
//-----------------------------------------------------------------------------
is_Expression* create_MultiOperator(is_Expression* oper1, operType type, is_Expression* oper2) {
	is_Expression* iE = (is_Expression*) malloc(sizeof(is_Expression));
	is_ExprMultOperators* iEMO = (is_ExprMultOperators*) malloc(sizeof(is_ExprMultOperators));
	iEMO->operand1 = oper1;
	iEMO->type = type;
	iEMO->operand2 = oper2;
	iE->data_declaration.iEMO = iEMO;
	iE->type = EXPR_MULT_OPERATORS;
	return iE;
}
//-----------------------------------------------------------------------------
is_Expression* create_UniOperator(operType type, is_Expression* oper) {
	is_Expression* iE = (is_Expression*) malloc(sizeof(is_Expression));
	is_ExprUniOperators* iEUO = (is_ExprUniOperators*) malloc(sizeof(is_ExprUniOperators));
	iEUO->type = type;
	iEUO->operand = oper;
	iE->data_declaration.iEUO = iEUO;
	iE->type = EXPR_UNI_OPERATORS;
	return iE;
}
//-----------------------------------------------------------------------------
is_Expr1* create_GetArrayAcess(is_Expr1* iE1, is_Expression* iExpr) {
	is_Expr1* iE1New = (is_Expr1*) malloc(sizeof(is_Expr1));
	is_ExprArrIndex* iEAI = (is_ExprArrIndex*) malloc(sizeof(is_ExprArrIndex));
	iEAI->iE1 = iE1;
	iEAI->iE = iExpr;
	iE1New->data_declaration.iEAI = iEAI;
	iE1New->type = EXPR_ARR_INDEX;
	return iE1New;
}
//-----------------------------------------------------------------------------
is_Expr1* create_MethodCall(char* id, is_MultExpression* iME) {
	is_Expr1* iE1 = (is_Expr1*)malloc(sizeof(is_Expr1));
	iE1->type = METHOD_CALL;
	is_MethodCall* iMC = (is_MethodCall*)malloc(sizeof(is_MethodCall));
	iE1->data_declaration.iMC = iMC;
	iMC->id = id;
	iMC->iME = iME;
	return iE1;
}
//-----------------------------------------------------------------------------
is_Expr1* create_Boolean(char* value) {
	is_Expr1* iE1 = (is_Expr1*) malloc(sizeof(is_Expr1));
	iE1->type = BOOLVALUE;
	is_BoolValue* iBV = (is_BoolValue*) malloc(sizeof(is_BoolValue));
	iE1->data_declaration.iBV = iBV;
	if(!strcmp(value, "true")) iBV->value = 1;
	else iBV->value = 0;
	return iE1;
}
//-----------------------------------------------------------------------------
is_Expr1* create_Int(char* value) {
	is_Expr1* iE1 = (is_Expr1*) malloc(sizeof(is_Expr1));
	iE1->type = INTVALUE;
	is_IntValue* iIV = (is_IntValue*) malloc(sizeof(is_IntValue));
	iE1->data_declaration.iIV = iIV;
	iIV->value = value;
	return iE1;
}
//-----------------------------------------------------------------------------
is_Expr1* create_ID(char* id) {
	is_Expr1* iE1 = (is_Expr1*) malloc(sizeof(is_Expr1));
	iE1->type = IDTF;
	is_IDTF* iI = (is_IDTF*) malloc(sizeof(is_IDTF));
	iE1->data_declaration.iI = iI;
	iI->id = id;
	return iE1;
}
//////////////////////////////////////////////////////////////////////////////
