#ifndef _HEADER_
#define _HEADER_

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "structures.h"
#include "functions.h"
#include "shows.h"
#include "symbols.h"
#include "y.tab.h"

extern char* yytext;
static int yycolumn = 1; 
static int commentLine = 0;
static int commentColumn = 0;
static int nTab = 0;
YYLTYPE yylloc;

#define YY_USER_ACTION yycolumn += yyleng; \
		yylloc.first_line = yylloc.last_line = yylineno; \
		yylloc.first_column = yycolumn-yyleng; yylloc.last_column = yycolumn-1;
#define YYLTYPE_IS_DECLARED 1
#define TAB 2

is_Program* program;
SymGeneric symP[NSYMS];
static int sizeSymP = 0;
SymVar* fieldTab[NSYMS];
SymMethod* methodTab[NSYMS];

#endif
