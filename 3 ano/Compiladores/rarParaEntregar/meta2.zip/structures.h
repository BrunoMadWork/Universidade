//////////////////////////////////////////////////////////////////////////////
#ifndef _STRUCTURES_
#define _STRUCTURES_
//////////////////////////////////// PROGRAMA ///////////////////////////////
typedef struct _exprMultOperators is_ExprMultOperators;
typedef struct _exprArrIndex is_ExprArrIndex;
typedef struct _exprNewArr is_ExprNewArr;
typedef struct _exprUniOperators is_ExprUniOperators;
typedef struct _expr1 is_Expr1;
typedef struct _expression is_Expression;
typedef struct _expr Expr;
typedef struct _expr1 Expr1;
typedef struct _multStatement is_MultStatement;
typedef struct _MultExpression is_MultExpression;
typedef struct _IntValue is_IntValue;
typedef struct _BoolValue is_BoolValue;
typedef struct _IDTF is_IDTF;
typedef struct _CurveExpression is_CurveExpression;
typedef struct _DotlenExpr is_DotlenExpr;
typedef struct _ParseintIDExpression is_ParseintIDExpression;
typedef struct _MethodCall is_MethodCall;
typedef struct _statement is_Statement;
typedef struct _IfThenElse is_IfThenElse;
typedef struct _While is_While;
typedef struct _Print is_Print;
typedef struct _Assignment is_Assignment;
typedef struct _Store isStore;
typedef struct _ArrayAssignment is_ArrayAssignment;
typedef struct _return is_Return;
typedef struct _multVarDecl is_MultVarDecl;
typedef struct _oFP is_OptionalFormalParams;
typedef struct _MethodDecl is_MethodDecl;
typedef struct _Body is_Body;
typedef struct _ListDeclaration is_ListDeclaration;
typedef struct _Program is_Program;
typedef struct _ListVar is_ListVar;
typedef struct _VarDecl is_VarDecl;
// se é um método ou variável 
typedef enum {is_VAR, is_METHOD} varOrMethod;
//-----------------------------------------------------------------------------
// esta struct pode ser um método ou uma declaração de variável 
struct _Body {
	varOrMethod vM;
	union {
		is_VarDecl* VarDecl;
		is_MethodDecl* MethodDecl; 
	} data_declaration;
};
//-----------------------------------------------------------------------------
// nó que tem uma struct Body e um ponteiro para o nó seguinte 
struct _ListDeclaration {
	is_Body* b;
	struct _ListDeclaration* next;
} ;
//-----------------------------------------------------------------------------
// lista para as declarações de variáveis e de métodos 
struct _Program {
	char* nome;
	is_ListDeclaration* lista;
};
/////////////////////////////////////// VARIÁVEIS ////////////////////////////////
// nó que tem o nome de uma variável e um ponteiro para o seguinte
struct _ListVar {
	char* nomeVar;
	struct _ListVar* next;
};
//-----------------------------------------------------------------------------
// diz o tipo da variável
typedef enum {
	fVOID = -1, INTEGER = 0, BOOLEAN = 1, INTEGER_ARR,
	BOOLEAN_ARR, STRING_TYPE, STRING_ARR
} varType;
// estrutura que tem o tipo da variável e uma lista com nome de variáveis
struct _VarDecl {
	varType type;
	is_ListVar* listaVars;
};
/////////////////////////////////////// MÉTODOS /////////////////////////////////
//-----------------------------------------------------------------------------
struct _IfThenElse {
	is_Expression* iE;
	is_Statement* iThenStat;
	is_Statement* iElseStat; 
} ;
//-----------------------------------------------------------------------------
struct _While {
	is_Statement* iWhileStat;
	is_Expression* iE;
};
//-----------------------------------------------------------------------------
struct _Print {
	is_Expression* iE;
} ;
//-----------------------------------------------------------------------------
struct _Store {
	is_Expression* left;
	is_Expression* right; 
};						
//-----------------------------------------------------------------------------
struct _Assignment {
	char* id;
	is_Expression* iE; 
};						
//-----------------------------------------------------------------------------
struct _ArrayAssignment {
	char* id;
	is_Expression* index;
	is_Expression* value;  
};
//-----------------------------------------------------------------------------
struct _return {
	is_Expression* iE; 
};						
//-----------------------------------------------------------------------------
typedef enum {
	STAT_WHILE, STAT_PRINT, STAT_IFTHENELSE, 
	STAT_ARRAY_ASSIGNMENT, STAT_ASSIGNMENT, STAT_RETURN, STAT_MULT
} statementType;
// struct para o statement
struct _statement {
	statementType type;
	union {
		is_IfThenElse* iITE;
		is_While* iW;
		is_Print* iP;
		is_Assignment* iA;
		is_ArrayAssignment* iAA;
		is_Return* iR;
		//is_Expression* iE; 
		is_MultStatement* iM;
	} data_declaration;
	//struct _statement* next;
} ;
//-----------------------------------------------------------------------------
typedef enum {
	IS_MULTBODY_FULL, IS_MULTBODY_NULL, 
	IS_MULT_NULL, IS_MULT_FULL
} multType;
// lista ligada de statements múltiplos
struct _multStatement {
	multType type;
	struct _multStatement* next;
	is_Statement* iS;
};
//-----------------------------------------------------------------------------
// struct que suscita listas de listas ligadas
struct _multVarDecl {
	multType type;
	struct _multVarDecl* next;
 	is_VarDecl* varDecl;
};
//-----------------------------------------------------------------------------
// struct que contém o tipo e o nome da variável
struct _oFP {
	varType type;
	char* nome;
	struct _oFP* next;
};
//-----------------------------------------------------------------------------
typedef enum {
	E, OU, IG, NAO_IG, MAIOR, MENOR, IG_MAIOR, IG_MENOR, 
	SOMA, TIRA, ASTERISC, DIVIDE, RESTO, NEGA, PLUS, MINUS 
} operType; 
// variáveis e de expressões
struct _MethodDecl {
	varType type;
	char* nome;
	is_OptionalFormalParams* iOFP;
 	is_MultVarDecl* iMVD;
 	is_MultStatement* iMS;
};
//-----------------------------------------------------------------------------
struct _exprMultOperators {
	is_Expression* operand1;
	operType type;
	is_Expression* operand2;
};
//-----------------------------------------------------------------------------
struct _exprArrIndex {
	is_Expr1* iE1;
	is_Expression* iE;
};
//-----------------------------------------------------------------------------
struct _exprNewArr {
	varType type;
	is_Expression* iE;
};
//-----------------------------------------------------------------------------
struct _exprUniOperators{
	operType type;
	is_Expression* operand;
};
//-----------------------------------------------------------------------------
struct _MultExpression {
	is_Expression* iE;
	struct _MultExpression* next; 
};
//-----------------------------------------------------------------------------
typedef enum {
	EXPR_MULT_OPERATORS, EXPR_NEW_ARR, 
	EXPR_UNI_OPERATORS, EXPR_NULL, EXPR1
} exprType;
//struct para a Expression
struct _expression {
	exprType type;
	union {
		is_ExprMultOperators* iEMO;
		is_ExprNewArr* iENA;
		is_ExprUniOperators* iEUO;
		is_Expr1* expr1;
	} data_declaration;
	struct _expression* next; 
};
//-----------------------------------------------------------------------------
typedef enum {
	NOT_VALID = -2, INTVALUE = 0, BOOLVALUE = 1, CRV_EXPR,
	DOTLEN_EXPR, PARSEINT_ID_EXPR, METHOD_CALL, IDTF, EXPR_ARR_INDEX
} expr1Type;
struct _expr1 {
	expr1Type type;
	union {
		is_IDTF* iI;
		is_IntValue* iIV;
		is_BoolValue* iBV;
		is_CurveExpression* iCE;
		is_DotlenExpr* iDE;
		is_ParseintIDExpression* iPIE; 
		is_MethodCall* iMC;
		is_ExprArrIndex* iEAI;
	} data_declaration;
	struct _expression* next;
};
//-----------------------------------------------------------------------------
struct _IntValue {
	char* value;
};
//-----------------------------------------------------------------------------
struct _BoolValue {
	int value;
};
//-----------------------------------------------------------------------------
struct _IDTF {
	char* id;
};
//-----------------------------------------------------------------------------
struct _CurveExpression {
	is_Expression* iE;
};
//-----------------------------------------------------------------------------
struct _DotlenExpr {
	is_Expression* iE;
};
//-----------------------------------------------------------------------------
struct _ParseintIDExpression {
	char* id;
	is_Expression* iE;
};
//-----------------------------------------------------------------------------
struct _MethodCall {
	char* id;
	is_MultExpression* iME;
};
//-----------------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////////////
#endif
//////////////////////////////////////////////////////////////////////////////
