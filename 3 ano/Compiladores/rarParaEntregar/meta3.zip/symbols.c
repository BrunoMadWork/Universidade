//////////////////////////////////////////////////////////////////////////////
#include "header.h"
//////////////////////////////////////////////////////////////////////////////
SymVar** symVarLook(SymVar* tab[], char* varName) {
    int i;      
    for (i=0; i<NSYMS && tab[i]; i++){
        if (! strcmp(varName, tab[i]->name)) 
            return &tab[i];
    }
    if (i < NSYMS) return &tab[i];
	assert(i < NSYMS);
}
//-----------------------------------------------------------------------------
SymMethod** symMethodLook(SymMethod* tab[], char* methodName) {
    int i;      
    for (i=0; i<NSYMS && tab[i]; i++){
        if (! strcmp(methodName, tab[i]->name)) 
            return &tab[i];
    }
    if (i < NSYMS) {
		return &tab[i];
    }
	assert(i < NSYMS);
}
//-----------------------------------------------------------------------------
void symTabPrint(SymGeneric tab[]) {
    printf("===== Class %s Symbol Table =====\n", program->nome);
    int i;
    SymMethod* met;
    SymVar* var;
    for (i = 0; i < sizeSymP; i++) {
        if (tab[i].type == is_METHOD) {
        	met = tab[i].value.method;
        	printf("%s\tmethod\n", met->name);
        } else {
        	var = tab[i].value.staticVar;
        	printf("%s\t%s\n", var->name, toStringType(var->type));
        }
    }
}
//-----------------------------------------------------------------------------
void symVarPrint(SymVar* tab[]) {
    int i;
    for (i = 0; i < NSYMS && tab[i]; i++) {
        printf("%s\t%s\n", tab[i]->name, toStringType(tab[i]->type));
    }
}
//-----------------------------------------------------------------------------
void symParamVarPrint(SymVar* tab[]) {
    int i;
    for (i = 0; i < NSYMS && tab[i]; i++) {
        printf("%s\t%s\tparam\n", tab[i]->name, toStringType(tab[i]->type));
    }
}
//-----------------------------------------------------------------------------
void symMethodPrint(SymMethod* tab[]) {
    int i;
    for (i = 0; i < NSYMS && tab[i]; i++) {
 		printf("\n===== Method %s Symbol Table =====\n", tab[i]->name);
        printf("return\t%s\n", methodTypeReturn(tab[i]->returnType));
    	symParamVarPrint(tab[i]->paramTab);
    	symVarPrint(tab[i]->varTab);
    }
}
//-----------------------------------------------------------------------------
char* methodTypeReturn(varType returnType) {
    switch(returnType) {
	case fVOID:       return "void";
    case INTEGER:     return "int";
    case BOOLEAN: 	  return "boolean";
	case INTEGER_ARR: return "int[]";
    case BOOLEAN_ARR: return "boolean[]";
    }
}
//-----------------------------------------------------------------------------
void insert_SymVarDecl(SymVar* campoTab[], is_VarDecl* iVD) {
	varType type = iVD->type;
	is_ListVar* lista = iVD->listaVars;
	is_ListVar* aux;
	for(aux = lista; aux->next; aux = aux->next) {
		SymVar** slot = symVarLook(campoTab, aux->nomeVar);
		SymMethod** slotMethodForVar = symMethodLook(methodTab, aux->nomeVar);
		if (*slot || *slotMethodForVar) { // métodos e variáveis não podem ter o mesmo nome
			printf("Symbol %s already defined\n", aux->nomeVar);
			exit(0);
		}
		switch(type) {
		case INTEGER:
			insert_IntSymbol(slot, aux->nomeVar);
			break;
		case BOOLEAN:
			insert_BooleanSymbol(slot, aux->nomeVar);
			break;
		case INTEGER_ARR:
			insert_IntArrSymbol(slot, aux->nomeVar);
			break;
		case BOOLEAN_ARR:
			insert_BooleanArrSymbol(slot, aux->nomeVar);
			break;		
		}
		symP[sizeSymP].type = is_VAR;
		symP[sizeSymP++].value.staticVar = *slot;
		assert(sizeSymP < NSYMS);
	}
}
//-----------------------------------------------------------------------------
void insert_IntSymbol(SymVar** slot, char* nome) {
	SymVar* sym = (SymVar*)malloc(sizeof(SymVar));
	sym->name = nome;
	sym->type = INTEGER;
	//sym->value.iValue = 0;
	*slot = sym;
}
//-----------------------------------------------------------------------------
void insert_BooleanSymbol(SymVar** slot, char* nome) {
	SymVar* sym = (SymVar*)malloc(sizeof(SymVar));
	sym->name = nome;
	sym->type = BOOLEAN;
	//sym->value.bValue = 0;
	*slot = sym;
}
//-----------------------------------------------------------------------------
void insert_IntArrSymbol(SymVar** slot, char* nome) {
	SymVar* sym = (SymVar*)malloc(sizeof(SymVar));
	sym->name = nome;
	sym->type = INTEGER_ARR;
	//sym->value.iArrValue = NULL;
	*slot = sym;
}
//-----------------------------------------------------------------------------
void insert_BooleanArrSymbol(SymVar** slot, char* nome) {
	SymVar* sym = (SymVar*)malloc(sizeof(SymVar));
	sym->name = nome;
	sym->type = BOOLEAN_ARR;
	//sym->value.bArrValue = NULL;
	*slot = sym;
}
//-----------------------------------------------------------------------------
void insert_StringArrSymbol(SymVar** slot, char* nome) {
	SymVar* sym = (SymVar*)malloc(sizeof(SymVar));
	sym->name = nome;
	sym->type = STRING_ARR;
	//sym->value.bArrValue = NULL;
	*slot = sym;
}
//-----------------------------------------------------------------------------
void insert_Method(SymMethod* methods[], is_MethodDecl* iMD) {
	SymMethod* symM;
	varType type = iMD->type;
	is_OptionalFormalParams* listaFormals = iMD->iOFP;
	is_OptionalFormalParams* auxFormal;
	SymMethod** slot = symMethodLook(methods, iMD->nome);
	SymVar** slotVarForMethod = symVarLook(fieldTab, iMD->nome);
	if (*slot || *slotVarForMethod){
		printf( "Symbol %s already defined\n", iMD->nome);
		exit(0);
	}
	symM = (SymMethod*)malloc(sizeof(SymMethod));
    assert(symM);
    memset(symM->paramTab, 0, NSYMS*sizeof(SymVar*));
    symM->iMS = iMD->iMS;
	symM->name = iMD->nome;
	symM->returnType = type;
	for (auxFormal = listaFormals->next; auxFormal; auxFormal = auxFormal->next) {
		insert_FormalVars(symM->paramTab, auxFormal);
	}
	is_MultVarDecl* listaMethodVars = iMD->iMVD;
	is_MultVarDecl* auxMethodDecl;
    memset(symM->varTab, 0, NSYMS*sizeof(SymVar*));
	for (auxMethodDecl = listaMethodVars->next; 
			auxMethodDecl; auxMethodDecl = auxMethodDecl->next) {
		int type = auxMethodDecl->varDecl->type;
		is_ListVar* listaVars = auxMethodDecl->varDecl->listaVars;
		is_ListVar* iLV = auxMethodDecl->varDecl->listaVars;
		for (; iLV->next; iLV = iLV->next) {
			char* id = iLV->nomeVar;
			insert_MethodVars(symM->paramTab, symM->varTab, type, id);
		}
	}
	*slot = symM;
	symP[sizeSymP].type = is_METHOD;
	symP[sizeSymP++].value.method = symM;
	assert(sizeSymP < NSYMS);
}
//-----------------------------------------------------------------------------
int isSameMethod(SymMethod* method, is_MethodDecl* iMD) {
	SymVar** paramTab = method->paramTab;
	is_OptionalFormalParams* aux = iMD->iOFP->next;
	int i;
	for(i = 0; paramTab[i] && aux; aux = aux->next, ++i) {
		if(paramTab[i]->type != aux->type) return 0;
	}
	return 1;
}
//-----------------------------------------------------------------------------
int verifyMultStatement(is_MultStatement* iM, SymVar* methodParamTab[],
	SymVar* varTab[], varType ret) {
	is_MultStatement* auxMult;
	for (auxMult = iM->next; auxMult; auxMult = auxMult->next) {
		if (auxMult->type == IS_MULT_NULL || 
			auxMult->type == IS_MULTBODY_NULL) return 1;
		int val = verifyStatement(auxMult->iS, methodParamTab, varTab, ret);
	}
	return 1;
}

//-----------------------------------------------------------------------------
int verifyStatement(is_Statement* iS, SymVar* methodParamTab[], 
										SymVar* varTab[], varType ret) {
	varType idType, valueArr, tipo;
	exprType xprType;
	scope scp;
	switch (iS->type) {
	case STAT_IFTHENELSE:
		xprType =  getTypeExpression(iS->data_declaration.iITE->iE, methodParamTab, varTab);
		if (BOOLEAN != xprType) {
			printf("Incompatible type in %s statement (got %s, required boolean)\n",
						toStringStat(iS->type), toStringType(xprType));
			exit(0);
		}
		verifyStatement(iS->data_declaration.iITE->iThenStat, methodParamTab, varTab, ret);
		if(iS->data_declaration.iITE->iElseStat)
			return verifyStatement(iS->data_declaration.iITE->iElseStat, methodParamTab, varTab, ret);
		return 1;
	case STAT_WHILE:
		xprType =  getTypeExpression(iS->data_declaration.iW->iE, methodParamTab, varTab);
		if (BOOLEAN != xprType) {
			printf("Incompatible type in %s statement (got %s, required boolean)\n",
						toStringStat(iS->type), toStringType(xprType));
			exit(0);
		}
		return verifyStatement(iS->data_declaration.iW->iWhileStat, methodParamTab, varTab, ret);
	case STAT_PRINT:
		tipo = getTypeExpression(iS->data_declaration.iP->iE, methodParamTab, varTab);
		if(tipo != INTEGER && tipo != BOOLEAN) {
			printf("Incompatible type in System.out.println statement (got %s, required boolean or int)\n"
								, toStringType(tipo));
			exit(0);
		}
		return tipo;
	case STAT_ARRAY_ASSIGNMENT:
		xprType = getTypeExpression(iS->data_declaration.iAA->index, methodParamTab, varTab);
		idType = getVarType(iS->data_declaration.iAA->id, methodParamTab, varTab, &scp);
		valueArr = getTypeExpression(iS->data_declaration.iAA->value, methodParamTab, varTab);
		if (INTEGER != xprType) { // índice não é INTEIRO
			printf("Operator [ cannot be applied to types %s, %s\n", toStringType(idType), toStringType(xprType));
			exit(0);
		}
		if (!isArrayType(idType)){ // o id do lado esquerdo não é um array
			printf("Operator [ cannot be applied to types %s, %s\n",
				toStringType(idType), toStringType(xprType));
			exit(0);
		}
		if (isArrayType(idType) &&  (getArrayType(idType) == valueArr)) {
			iS->data_declaration.iAA->idType = idType;
			iS->data_declaration.iAA->scp = scp;
			return 1; // o tipo do array bate certo com o valor do lado direito
		}
		if (isArrayType(idType) &&  (getArrayType(idType) != valueArr)) {
			printf("Incompatible type in assignment to %s[] (got %s, required %s)\n",
				iS->data_declaration.iAA->id, toStringType(valueArr), toStringType(getArrayType(idType)));
			exit(0);
		}
		printf("Wrong Exit!:verifyStatement\n");
		exit(0);
	case STAT_ASSIGNMENT:
		idType = getVarType(iS->data_declaration.iA->id, methodParamTab, varTab, &scp);
		valueArr = getTypeExpression(iS->data_declaration.iA->iE, methodParamTab, varTab);
		if (idType != valueArr) {
			printf("Incompatible type in assignment to %s (got %s, required %s)\n",
				iS->data_declaration.iA->id, toStringType(valueArr), toStringType(idType));
			exit(0);
		}
		iS->data_declaration.iA->scp = scp;
		iS->data_declaration.iA->idType = idType;
		return idType == valueArr;
	case STAT_MULT:
		return verifyMultStatement(iS->data_declaration.iM, methodParamTab, varTab, ret);
	case STAT_RETURN:
		if (! iS->data_declaration.iR->iE && ret == fVOID) return 1;
		if (! iS->data_declaration.iR->iE && ret != fVOID) {
			printf("Incompatible type in %s statement (got void, required %s)\n",
 						toStringStat(STAT_RETURN),
 						toStringType(ret));
			exit(0);
		}
		tipo = getTypeExpression(iS->data_declaration.iR->iE, methodParamTab, varTab);
		if (tipo != ret) {
			printf("Incompatible type in %s statement (got %s, required %s)\n",
			 			toStringStat(STAT_RETURN), toStringType(tipo), toStringType(ret));
			exit(0);
		}
		return 0;
	}
	return 0;
}
//-----------------------------------------------------------------------------
int isArrayType(varType typeV) {
	if(typeV == INTEGER_ARR || typeV == BOOLEAN_ARR)
		return 1;
	return 0;
}
//-----------------------------------------------------------------------------
int getArrayFromNonArrayType(varType typeV) {
	switch(typeV) {
	case STRING_TYPE: return STRING_ARR;
	case INTEGER: return INTEGER_ARR;
	case BOOLEAN: return BOOLEAN_ARR;
	}
}
//-----------------------------------------------------------------------------
int getArrayType(varType typeV) {
	switch(typeV) {
	case STRING_ARR: return STRING_TYPE;
	case INTEGER_ARR: return INTEGER;
	case BOOLEAN_ARR: return BOOLEAN;
	}
}
//-----------------------------------------------------------------------------
varType getVarType(char* id, SymVar* methodParamTab[], SymVar* varTab[], scope* scp) {
	SymVar** symVar;
	symVar = symVarLook(methodParamTab, id);
	if (*symVar) {
		*scp = PARAM;
		return (*symVar)->type;
	}
	symVar = symVarLook(varTab, id);
	if (*symVar) {
		*scp = LOCAL;
		return (*symVar)->type;
	}
	symVar = symVarLook(fieldTab, id);
	if (*symVar) {
		*scp = GLOBAL;
		return (*symVar)->type;
	}
	printf("Cannot find symbol %s\n", id);
	exit(0);
 	return NOT_VALID;
}
//-----------------------------------------------------------------------------
varType getTypeExpression(is_Expression* iE, SymVar* methodParamTab[],  SymVar* varTab[]) {
	varType type, type2, tipo, newTipo;
	int operator;
	switch (iE->type) {
	case EXPR_NEW_ARR:
		newTipo = iE->data_declaration.iENA->type;
		tipo = getTypeExpression(iE->data_declaration.iENA->iE, methodParamTab, varTab);
		if (INTEGER != tipo) {
			printf("Operator new %s cannot be applied to type %s\n", 
				toStringType(getArrayType(newTipo)), toStringType(tipo));
			exit(0);
		}
		iE->vType =  newTipo;
		return iE->data_declaration.iENA->type;
	case EXPR_UNI_OPERATORS:
		operator = iE->data_declaration.iEUO->type;
		type = getTypeExpression(iE->data_declaration.iEUO->operand, methodParamTab, varTab);
		if (type == BOOLEAN && operator == NEGA ) {
			iE->vType = type;
			return type;
		}
		if (type == INTEGER && (operator == PLUS || operator == MINUS) ) {
			iE->vType = type;
			return type;
		}
		printf("Operator %s cannot be applied to type %s\n", toStringOperator(operator), toStringType(type));
		exit(0);
	case EXPR_MULT_OPERATORS:
		operator = iE->data_declaration.iEMO->type;
		type = getTypeExpression(iE->data_declaration.iEMO->operand1, methodParamTab, varTab);
		type2 = getTypeExpression(iE->data_declaration.iEMO->operand2, methodParamTab, varTab);
		if (type != type2) {
			printf("Operator %s cannot be applied to types %s, %s\n", 
				toStringOperator(operator), toStringType(type), toStringType(type2));
			exit(0);
		}
		if (type == INTEGER && (operator == SOMA || operator == TIRA ||
			operator == ASTERISC || operator == RESTO || operator == DIVIDE)) {
			iE->vType = INTEGER;
			return INTEGER;
		}
		if (type == INTEGER && (operator == IG || operator == NAO_IG ||
			operator == MAIOR || operator == MENOR || operator == IG_MAIOR ||
			operator == IG_MENOR)) {
			iE->vType = BOOLEAN;
			return BOOLEAN;
		}	
		if (type == BOOLEAN &&
			(operator == E || operator == OU ||
			operator == IG || operator == NAO_IG)) {
			iE->vType = BOOLEAN;
			return BOOLEAN;
		}	
		printf("Operator %s cannot be applied to types %s, %s\n", 
				toStringOperator(operator), toStringType(type), toStringType(type2));
		exit(0);
	case EXPR1:
		type = getTypeExpr1(iE->data_declaration.expr1, methodParamTab, varTab);
		iE->vType = type;
		return type;
	}
	return NOT_VALID;
}
//-----------------------------------------------------------------------------
int isValidIntLit(char* value, int* intValue) {
	int i;
	int sz = strlen(value);
	if (value[0] == '0' && value[1] == '\0') {
		*intValue = 0;
		return 1;
	}
	if (value[0] == '0' && value[1] == 'x' && value[2] == '\0'){
		return 0;
	}
	if (value[0] == '0' && value[1] == 'x'){
		sscanf(value, "%x", intValue);
		return 1;
	}
	if (value[0] == '0') {
		for (i = 1; i < sz; ++i) if (value[i] > '7') return 0;
		sscanf(value, "%o", intValue);
		return 1;
	}
	for (i = 1; i < sz; ++i) if (value[i] > '9') return 0; 
	sscanf(value, "%d", intValue);
	return 1;
}
//-----------------------------------------------------------------------------
varType getTypeExpr1(is_Expr1* iE1, SymVar* methodParamTab[], SymVar* varTab[]) {
	varType type, tipo;
	SymVar** slotIdParseInt1, **slotIdParseInt2;
	scope scp;
	char* id;
	switch (iE1->type) {
	case CRV_EXPR:
		type = getTypeExpression(iE1->data_declaration.iCE->iE, methodParamTab, varTab);
		iE1->vType = type;
		return type;			
	case DOTLEN_EXPR:
		type = getTypeExpression(iE1->data_declaration.iDE->iE, methodParamTab, varTab);
		if ((type == INTEGER_ARR) || (type == BOOLEAN_ARR) || (type == STRING_ARR)){
			iE1->vType = INTEGER;
			return INTEGER;
		}
		printf("Operator .length cannot be applied to type %s\n", toStringType(type));
		exit(0);
	case BOOLVALUE:
		iE1->vType = BOOLEAN;
		return BOOLEAN;
	case INTVALUE:
		if(!isValidIntLit(iE1->data_declaration.iIV->value, &(iE1->data_declaration.iIV->intValue))) {
			printf("Invalid literal %s\n", iE1->data_declaration.iIV->value);
			exit(0);
		} 
		iE1->vType = INTEGER;
		return INTEGER;
	case IDTF:
		type = getVarType(iE1->data_declaration.iI->id, methodParamTab, varTab, &scp);				
		iE1->vType = type;
		iE1->data_declaration.iI->scp = scp;
		return type;
	case METHOD_CALL:
		type = getMethodType(iE1->data_declaration.iMC, methodParamTab, varTab);
		iE1->vType = type;
		return type;				
	case PARSEINT_ID_EXPR:
		type = getVarType(iE1->data_declaration.iPIE->id, methodParamTab, varTab, &scp);
		tipo = getTypeExpression(iE1->data_declaration.iPIE->iE, methodParamTab, varTab);
		if(INTEGER != tipo) {
			printf("Operator Integer.parseInt cannot be applied to types %s, %s\n"
				, toStringType(type), toStringType(tipo));
			exit(0);
		}
		id = iE1->data_declaration.iPIE->id;
		if(STRING_ARR != type){
			printf("Operator Integer.parseInt cannot be applied to types %s, %s\n"
				, toStringType(type), toStringType(tipo));				
			exit(0);
		}
		iE1->vType = INTEGER;
		return INTEGER;
	case EXPR_ARR_INDEX:
		type = getTypeExpr1(iE1->data_declaration.iEAI->iE1, methodParamTab, varTab);
		tipo = getTypeExpression(iE1->data_declaration.iEAI->iE, methodParamTab, varTab);
		if (INTEGER != tipo) {
			printf("Operator [ cannot be applied to types %s, %s\n", toStringType(type), toStringType(tipo));
			exit(0);
		}
		switch (type) {
			case INTEGER_ARR:
				iE1->data_declaration.iEAI->arrayType = INTEGER_ARR; 
				iE1->vType = INTEGER;
				return INTEGER;
			case BOOLEAN_ARR: 
				iE1->data_declaration.iEAI->arrayType = BOOLEAN_ARR;
				iE1->vType = BOOLEAN;
				return BOOLEAN;
		}
		printf("Operator [ cannot be applied to types %s, %s\n", toStringType(type), toStringType(tipo));
		exit(0);
	}
 	return NOT_VALID;
}
//-----------------------------------------------------------------------------
varType getMethodType(is_MethodCall* iMC, SymVar* methodParamTab[], SymVar* varTab[]) {
	varType type, var;
	int i = 0;
	SymMethod** method = symMethodLook(methodTab, iMC->id);
	if (! *method) {
		printf("Cannot find symbol %s\n", iMC->id);
		exit(0);
	}
	is_MultExpression* curr = iMC->iME->next;
	for (; curr && (*method)->paramTab[i]; curr = curr->next, ++i) {
		type =  getTypeExpression(curr->iE, methodParamTab, varTab); // tipo da variável da chamada
		var = (*method)->paramTab[i]->type; // tipo da declaração do método MESMO
		if (type != var) {
			printf("Incompatible type of argument %d in call to method %s (got %s, required %s)\n",
						i, iMC->id, toStringType(type), toStringType(var));
			exit(0);
		}
	}
	if(curr)
		type =  getTypeExpression(curr->iE, methodParamTab, varTab);
	if((*method)->paramTab[i])
		var = (*method)->paramTab[i]->type;
	if (!curr && !((*method)->paramTab[i])) 
		return (*method)->returnType;
	if(!curr && (*method)->paramTab[i]) {
		printf("Incompatible type of argument %d in call to method %s (got void, required %s)\n"
			, i, iMC->id, toStringType(var));
		exit(0);
	}
	if(curr && !(*method)->paramTab[i]) {
		printf("Incompatible type of argument %d in call to method %s (got %s, required void)\n"
			, i, iMC->id, toStringType(type));
		exit(0);
	}
	printf("Wrong Exit!:getMethodType\n");
	exit(0);
}
//-----------------------------------------------------------------------------
char* toStringStat(statementType vType) {
	switch(vType) {
	case STAT_WHILE: return "while";
	case STAT_PRINT: return "System.out.println";
	case STAT_IFTHENELSE: return "if";
	case STAT_ARRAY_ASSIGNMENT: return "assignment";
	case STAT_ASSIGNMENT: return "assignment";
	case STAT_RETURN: return "return";	
	}
}
//-----------------------------------------------------------------------------
char* toStringType(varType vType) {
	switch(vType) {
	case INTEGER: return "int";
	case BOOLEAN: return "boolean";
	case INTEGER_ARR: return "int[]";
	case BOOLEAN_ARR: return "boolean[]";
	case STRING_TYPE: return "String";
	case STRING_ARR: return "String[]";
	case fVOID: return "void";	
	}
}
//-----------------------------------------------------------------------------
char* toStringOperator(operType vType) {
	switch(vType) {
	case OU: return "||";
	case E: return "&&";
	case IG: return "==";
	case NAO_IG: return "!=";
	case MAIOR: return ">";
	case MENOR: return "<";
	case IG_MAIOR: return ">=";
	case IG_MENOR: return "<=";
	case SOMA: case PLUS: return "+";
	case TIRA: case MINUS: return "-";
	case ASTERISC: return "*";
	case DIVIDE: return "/";
	case RESTO: return "%";
	case NEGA: return "!";
	}
}
//-----------------------------------------------------------------------------
void insert_FormalVars(SymVar* varTab[], is_OptionalFormalParams* var) {
	SymVar** slotVar = symVarLook(varTab, var->nome);
	if (*slotVar) {
		printf("Symbol %s already defined\n", var->nome);
		exit(0);
	}
	switch(var->type) {
	case INTEGER:
		insert_IntSymbol(slotVar, var->nome);
		break;
	case BOOLEAN:
		insert_BooleanSymbol(slotVar, var->nome);
		break;
	case INTEGER_ARR:
		insert_IntArrSymbol(slotVar, var->nome);
		break;
	case BOOLEAN_ARR:
		insert_BooleanArrSymbol(slotVar, var->nome);
		break;		
	case STRING_ARR:
		insert_StringArrSymbol(slotVar, var->nome);
		break;		
	}
}
//-----------------------------------------------------------------------------
void insert_MethodVars(SymVar* parTab[], SymVar* varTab[], varType type, char* id) {
	SymVar** slotVar2 = symVarLook(parTab, id);
	if (*slotVar2) {
		printf("Symbol %s already defined\n", id);
		exit(0);
	}
	SymVar** slotVar = symVarLook(varTab, id);
	if (*slotVar) {
		printf("Symbol %s already defined\n", id);
		exit(0);
	}
	switch(type) {
	case INTEGER:
		insert_IntSymbol(slotVar, id);
		break;
	case BOOLEAN:
		insert_BooleanSymbol(slotVar, id);
		break;
	case INTEGER_ARR:
		insert_IntArrSymbol(slotVar, id);
		break;
	case BOOLEAN_ARR:
		insert_BooleanArrSymbol(slotVar, id);
		break;				
	}
}
//////////////////////////////////////////////////////////////////////////////
