//////////////////////////////////////////////////////////////////////////////
#include "header.h"
//////////////////////////////////////////////////////////////////////////////
void printSpaces(int size) {
	int i;
	//printf("%d\t", size);
	for (i = 0; i < TAB*size; ++i) printf(" ");
}
//-----------------------------------------------------------------------------
void show_program(is_Program* iP) {
	printf("Program\n");
	nTab++;
	printSpaces(nTab);
	printf("Id(%s)\n", iP->nome);	
	is_ListDeclaration* start = iP->lista;
	is_ListDeclaration* aux;
	for (aux = start->next; aux; aux = aux->next) {
		printMethodOrDecl(aux);
	}
	nTab--;
}
//-----------------------------------------------------------------------------
void printMethodOrDecl(is_ListDeclaration* iLD) {
	switch (iLD->b->vM) {
		case is_VAR:
			printBodyVars(iLD);
			break;
		case is_METHOD:
			printMethod(iLD);
			break;
	}
}
//-----------------------------------------------------------------------------
void printBodyVars(is_ListDeclaration* iLD) {
	is_VarDecl* iVD = (is_VarDecl*) iLD->b->data_declaration.VarDecl;
	printVars(iVD);
}
//-----------------------------------------------------------------------------
void printVars(is_VarDecl* iVD) {
	printSpaces(nTab);
	printf("VarDecl\n");
	nTab++;
	printVarType(iVD);
	is_ListVar* start = iVD->listaVars;
	is_ListVar* aux;
	for (aux = start; aux; aux = aux->next) {
		if (aux && aux->nomeVar) { 
			printSpaces(nTab);
			printf("Id(%s)\n", aux->nomeVar);
		}
	}
	nTab--;
}
//-----------------------------------------------------------------------------
void printVarType(is_VarDecl* iVD) {
	printSpaces(nTab);
	switch (iVD->type) {
		case INTEGER:
			printf("Int\n");
			break;
		case BOOLEAN:
			printf("Bool\n");
			break;
		case INTEGER_ARR:
			printf("IntArray\n");
			break;
		case BOOLEAN_ARR:
			printf("BoolArray\n");
			break;
	}
}
//-----------------------------------------------------------------------------
void printMethod(is_ListDeclaration* iLD) {
	is_MethodDecl* iMD = (is_MethodDecl*) iLD->b->data_declaration.MethodDecl;
	printSpaces(nTab);
	printf("MethodDecl\n");

	nTab++;
	printFuncType(iMD);
	
	printSpaces(nTab);
	printf("Id(%s)\n", iMD->nome);

	printFormalParams(iMD->iOFP);

	printSpaces(nTab);
	printf("MethodBody\n");

	printMultVar(iMD->iMVD);

	printMultiStatement(iMD->iMS);
	nTab--;
}
//-----------------------------------------------------------------------------
void printFormalParams(is_OptionalFormalParams* iOFP) {
	printSpaces(nTab);
	printf("MethodParams\n");
	if(!iOFP->next) return;
	nTab++;
	is_OptionalFormalParams* aux;
	for (aux = iOFP->next; aux; aux = aux->next) {
		printSpaces(nTab);
		printf("ParamDeclaration\n");
		nTab++;
		printFormalParamsType(aux);
		printSpaces(nTab);
		printf("Id(%s)\n", aux->nome);
		nTab--;
	}
	nTab--;
}
//-----------------------------------------------------------------------------
void printFormalParamsType(is_OptionalFormalParams* iOFP) {
	printSpaces(nTab);
	switch (iOFP->type) {
		case INTEGER:
			printf("Int\n");
			break;
		case BOOLEAN:
			printf("Bool\n");
			break;
		case INTEGER_ARR:
			printf("IntArray\n");
			break;
		case BOOLEAN_ARR:
			printf("BoolArray\n");
			break;
		case STRING_ARR:
			printf("StringArray\n");
			break;
	}
}
//-----------------------------------------------------------------------------
void printFuncType(is_MethodDecl* iMD) {
	printSpaces(nTab);
	switch (iMD->type) {
		case INTEGER:
			printf("Int\n");
			break;
		case BOOLEAN:
			printf("Bool\n");
			break;
		case INTEGER_ARR:
			printf("IntArray\n");
			break;
		case BOOLEAN_ARR:
			printf("BoolArray\n");
			break;
		case fVOID:
			printf("Void\n");
			break;
	}
}
//-----------------------------------------------------------------------------
void printMultVar(is_MultVarDecl* iMVD) {
	nTab++;
	is_MultVarDecl* aux;
	for (aux = iMVD; aux->next; aux = aux->next) {
		printVars(aux->next->varDecl);
	}
	nTab--;
} 
//-----------------------------------------------------------------------------
void printMultiStatement(is_MultStatement* lista) {
	if(lista->next == NULL && lista->type == IS_MULT_NULL) {
		nTab++;
		printSpaces(nTab);
		printf("Null\n");
		nTab--;
		return;
	}
	is_MultStatement* aux;
	for (aux = lista->next; aux; aux = aux->next) {
		printStatement(aux->iS);
	}
}
//-----------------------------------------------------------------------------
void printStatement(is_Statement* iS) {
	int tab;
	int lenght;
	if(iS->type != STAT_MULT) {
		nTab++;
		printSpaces(nTab);
	}
	switch (iS->type) {
		case STAT_RETURN:
			printf("Return\n");
			if(iS->data_declaration.iR->iE)
				printExpression(iS->data_declaration.iR->iE);
			break;
		case STAT_MULT:
			lenght = multStatLenght(iS->data_declaration.iM);
			if (lenght > 1) {
				nTab++;
				printSpaces(nTab);
				printf("CompoundStat\n");
				printMultiStatement(iS->data_declaration.iM);
				nTab--;
			}
			else
				printMultiStatement(iS->data_declaration.iM);
			break;
		case STAT_ASSIGNMENT:
			printf("Store\n");
			nTab++;
			printSpaces(nTab);
			printf("Id(%s)\n", iS->data_declaration.iA->id);
			nTab--;
			printExpression(iS->data_declaration.iA->iE);
			break;
		case STAT_ARRAY_ASSIGNMENT:
			printf("StoreArray\n");
			nTab++;
			printSpaces(nTab);
			printf("Id(%s)\n", iS->data_declaration.iAA->id);
			nTab--;
			printExpression(iS->data_declaration.iAA->index);
			printExpression(iS->data_declaration.iAA->value);
			break;
		case STAT_IFTHENELSE:
			printf("IfElse\n");
			printExpression(iS->data_declaration.iITE->iE);
			printStatement(iS->data_declaration.iITE->iThenStat);
			if(iS->data_declaration.iITE->iElseStat) 
				printStatement(iS->data_declaration.iITE->iElseStat);
			else{
				nTab++;
				printSpaces(nTab);	
				printf("Null\n");
				nTab--;
			}
			break;	
		case STAT_WHILE:
			tab = nTab;
			printf("While\n");
			printExpression(iS->data_declaration.iW->iE);
			nTab = tab;
			printStatement(iS->data_declaration.iW->iWhileStat);
			break;	
		case STAT_PRINT:
			printf("Print\n");
			printExpression(iS->data_declaration.iP->iE);
			break;	
	}
	if(iS->type != STAT_MULT) {
		nTab--;
	}
}
//-----------------------------------------------------------------------------
void printMultExpression(is_MultExpression* lista) {
	is_MultExpression* aux;
	for (aux = lista->next; aux; aux = aux->next) {
		printExpression(aux->iE);
	}
}
//-----------------------------------------------------------------------------
void printExpression(is_Expression* iE) {
	switch (iE->type) {
		case EXPR1:
			printExpr1(iE->data_declaration.expr1);
			break;
		case EXPR_NEW_ARR:
			switch(iE->data_declaration.iENA->type) {
				case INTEGER_ARR: 
					nTab++;
					printSpaces(nTab);
					printf("NewInt\n");
					printExpression(iE->data_declaration.iENA->iE);
					nTab--;
					break;
				case BOOLEAN_ARR:
					nTab++;
					printSpaces(nTab);
					printf("NewBool\n");
					printExpression(iE->data_declaration.iENA->iE);
					nTab--;
					break;
			}
			break;
		case EXPR_MULT_OPERATORS:
			printOperator(iE->data_declaration.iEMO->type);
			nTab++;	
			printExpression(iE->data_declaration.iEMO->operand1);
			printExpression(iE->data_declaration.iEMO->operand2);
			nTab--;
			break;			
		case EXPR_UNI_OPERATORS:
			printOperator(iE->data_declaration.iEUO->type);
			nTab++;			
			printExpression(iE->data_declaration.iEUO->operand);
			nTab--;
			break;
	}
}
void printOperator(operType type){
	nTab++;
	printSpaces(nTab);
	switch(type) {
		case E:
			printf("And");
			break;
		case OU:
			printf("Or");
			break;	
		case IG:
			printf("Eq");
			break;	
		case NAO_IG:
			printf("Neq");
			break;	
		case MAIOR:
			printf("Gt");
			break;	
		case MENOR:
			printf("Lt");
			break;	
		case IG_MAIOR:
			printf("Geq");
			break;	
		case IG_MENOR:
			printf("Leq");
			break;	
		case SOMA:
			printf("Add");
			break;							
		case TIRA:
			printf("Sub");
			break;
		case ASTERISC:
			printf("Mul");
			break;
		case DIVIDE:
			printf("Div");
			break;
		case RESTO:
			printf("Mod");
			break;
		case NEGA:
			printf("Not");
			break;
		case PLUS:
			printf("Plus");
			break;							
		case MINUS:
			printf("Minus");
			break;					
	}
	printf("\n");
	nTab--;
}
//-----------------------------------------------------------------------------
void printExpr1(is_Expr1* iE1) {
	if(iE1->type != CRV_EXPR) {
		nTab++;
		printSpaces(nTab);
	}
	switch (iE1->type) {
		case INTVALUE:
			printf("IntLit(%s)\n", iE1->data_declaration.iIV->value);
			break;
		case BOOLVALUE:
			if(iE1->data_declaration.iBV->value)
				printf("BoolLit(true)\n");
			else 
				printf("BoolLit(false)\n");
			break;	
		case IDTF:
			printf("Id(%s)\n", iE1->data_declaration.iI->id);
			break;
		case CRV_EXPR:
			printExpression(iE1->data_declaration.iCE->iE);
			break;
		case DOTLEN_EXPR:
			printf("Length\n");
			printExpression(iE1->data_declaration.iDE->iE);
			break;
		case PARSEINT_ID_EXPR:
			printf("ParseArgs\n");
			nTab++;
			printSpaces(nTab);
			printf("Id(%s)\n", iE1->data_declaration.iPIE->id);
			nTab--;
			printExpression(iE1->data_declaration.iPIE->iE);
			//nTab--;
			break;		
		case METHOD_CALL:
			printf("Call\n");
			nTab++;
			printSpaces(nTab);
			printf("Id(%s)\n", iE1->data_declaration.iMC->id);
			nTab--;
			printMultExpression(iE1->data_declaration.iMC->iME);
			break;
		case EXPR_ARR_INDEX:
			printf("LoadArray\n");
			printExpr1(iE1->data_declaration.iEAI->iE1);
			printExpression(iE1->data_declaration.iEAI->iE);
			break;
	}
	if(iE1->type != CRV_EXPR) {
		nTab--;
	}
}
//////////////////////////////////////////////////////////////////////////////
