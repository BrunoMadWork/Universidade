//////////////////////////////////////////////////////////////////////////////
#ifndef _CODEMAKER_
#define _CODEMAKER_
#include "header.h"
//////////////////////////////////////////////////////////////////////////////
void llvmStaticDecl();
void llvmGlobalVars();
void llvmMethods();
void llvmMethodParams(SymVar** );
void llvmMethodVars(SymVar** );
char* typeToLLVM(varType );
char* typeToLLVMAuto(varType );
char* structLLVM(varType );
char scopeToLLVM(scope );
void generateMain(SymMethod* );
void generateMultStatement(is_MultStatement* );
void generateStatement(is_Statement* );
int generateExpression(is_Expression* );
int generateIntArray(is_Expression* );
int generateBooleanArray(is_Expression* );
int generateExpr1(is_Expr1* );
int generateMultOperators(is_Expression* );
int generateShortCircuitAnd(is_Expression* );
int generateShortCircuitOr(is_Expression* );
int generateUniOperators(is_Expression* );
int generateMethodCall(is_Expr1* );
//////////////////////////////////////////////////////////////////////////////
#endif
//////////////////////////////////////////////////////////////////////////////
