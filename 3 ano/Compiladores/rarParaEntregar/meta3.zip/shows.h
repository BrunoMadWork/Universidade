//////////////////////////////////////////////////////////////////////////////
#ifndef _SHOWSH_
#define _SHOWSH_
#include "header.h"
//////////////////////////////////////////////////////////////////////////////
void printSpaces(int );
void show_program(is_Program* );
void printMethodOrDecl(is_ListDeclaration* );
void printBodyVars(is_ListDeclaration* );
void printVars(is_VarDecl* );
void printVarType(is_VarDecl* );
void printMethod(is_ListDeclaration* );
void printFuncType(is_MethodDecl* );
void printMultVar(is_MultVarDecl* );
void printFormalParamsType(is_OptionalFormalParams* );
void printFormalParams(is_OptionalFormalParams* );
void printMultiStatement(is_MultStatement* );
void printMultExpression(is_MultExpression* );
void printStatement(is_Statement* );
void printExpression(is_Expression* );
void printOperator(operType );
void printExpr1(is_Expr1* );
//////////////////////////////////////////////////////////////////////////////
#endif
//////////////////////////////////////////////////////////////////////////////
