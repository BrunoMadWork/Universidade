//////////////////////////////////////////////////////////////////////////////
#include "header.h"
//////////////////////////////////////////////////////////////////////////////
int llvmN;
int ifN;
int whileN;
char isMain;
//////////////////////////////////////////////////////////////////////////////
void llvmStaticDecl() {
	printf("declare i32 @printf(i8*, ...)\n");
	printf("declare i32 @atoi(i8*)\n");
	printf("declare i8* @calloc(i32, i32)\n");
	printf("declare i8* @malloc(i32)\n");
	printf("\n");
	printf("@.int = private unnamed_addr constant [4 x i8] c\"%%d\\0A\\00\", align 1\n");
	printf("@.true = private unnamed_addr constant [6 x i8] c\"true\\0A\\00\", align 1\n");		
	printf("@.false = private unnamed_addr constant [7 x i8] c\"false\\0A\\00\", align 1\n");
	printf("@.intArrNull = common global %%struct.IntArray zeroinitializer\n");
	printf("@.boolArrNull = common global %%struct.BooleanArray zeroinitializer\n");
	printf("%%struct.IntArray = type {i32, i32*}\n");
	printf("%%struct.BooleanArray = type {i32, i1*}\n");
	printf("%%struct.StringArray = type {i32, i8**}\n");
	printf("\n");
}
//////////////////////////////////////////////////////////////////////////////
void llvmGlobalVars() {
	int i;
	varType type;
	for (i = 0; i < NSYMS && fieldTab[i]; ++i) {
		SymVar* var = fieldTab[i];
		type = var->type;
		switch (type) {
		case INTEGER: case BOOLEAN: 
			printf("@%s = global %s 0\n", var->name, typeToLLVMAuto(type));
			break;
		case INTEGER_ARR: case BOOLEAN_ARR:
			printf("@%s = common global %s zeroinitializer\n", var->name, typeToLLVMAuto(type));
			break;
		}
	}
	printf("\n");
}
//////////////////////////////////////////////////////////////////////////////
void llvmMethods() {
	int i;
	isMain = 0;
	for (i = 0; i < NSYMS && methodTab[i]; ++i) {
		whileN = ifN = llvmN = 0;
		SymMethod* method = methodTab[i];
		if (!strcmp(method->name, "main")) {
			isMain = 1;
			generateMain(method);
			isMain = 0;
			continue;
		}
		printf("define %s @%s", typeToLLVMAuto(method->returnType), method->name);
		llvmMethodParams(method->paramTab);
		printf("{\n");
		llvmMethodVars(method->varTab);
		generateMultStatement(method->iMS);
		switch(method->returnType) {
			case fVOID: printf("\tret void\n"); break;
			case INTEGER: printf("\tret i32 0\n"); break;
			case BOOLEAN: printf("\tret i1 0\n"); break;
			case INTEGER_ARR: printf("\tret %%struct.IntArray* @.intArrNull\n"); break;
			case BOOLEAN_ARR: printf("\tret %%struct.BooleanArray* @.boolArrNull\n"); break;
		}
		printf("}\n\n");
	}
}
//////////////////////////////////////////////////////////////////////////////
void generateMain(SymMethod* method) {
	int ARGS, pArgs, argsMinusOne;
	printf("define i32 @main");
	printf("(i32 %%.argc, i8** %%.argv) {\n");
	if (method->paramTab[0] && method->paramTab[0]->type == STRING_ARR) {
		char* args = method->paramTab[0]->name;
		printf("\t%%%s = alloca %%struct.StringArray*, align 4\n", args);
		ARGS = ++llvmN;
		printf("\t%%%d = alloca %%struct.StringArray, align 4\n", llvmN);
		printf("\tstore %%struct.StringArray* %%%d, %%struct.StringArray** %%%s\n",
			llvmN, args);
		pArgs = ++llvmN;
		printf("\t%%%d = getelementptr %%struct.StringArray* %%%d, i32 0, i32 0\n",
			llvmN, ARGS);
		argsMinusOne = ++llvmN;
		printf("\t%%%d = add i32 %%.argc, -1\n", argsMinusOne);
		printf("\tstore i32 %%%d, i32* %%%d\n", argsMinusOne, pArgs);
		++llvmN;
		printf("\t%%%d = getelementptr %%struct.StringArray* %%%d, i32 0, i32 1\n",
			llvmN, ARGS);
		++llvmN;
		printf("\t%%%d = getelementptr i8** %%.argv, i32 1\n", llvmN);
		printf("\tstore i8** %%%d, i8*** %%%d\n", llvmN, llvmN-1);
	}
	llvmMethodVars(method->varTab);
	generateMultStatement(method->iMS);
	printf("\tret i32 0\n");
	printf("}\n\n");
}
//////////////////////////////////////////////////////////////////////////////
void llvmMethodParams(SymVar** paramTab) {
	int i;
	printf("(");
	if (paramTab[0]) printf("%s %%%s", 
		typeToLLVM(paramTab[0]->type), paramTab[0]->name);
	for (i = 1; i < NSYMS && paramTab[i]; ++i) {
		SymVar* param = paramTab[i];
		printf(", %s %%%s", typeToLLVM(param->type), param->name);		
	}
	printf(") ");
}
//////////////////////////////////////////////////////////////////////////////
void llvmMethodVars(SymVar** varTab) {
	int i;
	for (i = 0; i < NSYMS && varTab[i]; ++i) {
		SymVar* var = varTab[i];
		printf("\t%%%s = alloca %s\n", var->name, typeToLLVMAuto(var->type));
		switch(var->type) {
			case INTEGER: printf("\tstore i32 0, i32* %%%s\n", var->name); break;
			case BOOLEAN: printf("\tstore i1 0, i1* %%%s\n", var->name); break;
			case INTEGER_ARR: printf("\tstore %%struct.IntArray* @.intArrNull"
				" , %%struct.IntArray** %%%s\n", var->name); break;
			case BOOLEAN_ARR: printf("\tstore %%struct.BooleanArray* @.boolArrNull"
				" , %%struct.BooleanArray** %%%s\n", var->name); break;
		}		
	}
}
//////////////////////////////////////////////////////////////////////////////
char* typeToLLVM(varType type) {
	switch (type) {
		case fVOID: 	  return "void";
		case INTEGER: 	  return "i32*";
		case BOOLEAN:     return "i1*";
		case INTEGER_ARR: return "%struct.IntArray**";
		case BOOLEAN_ARR: return "%struct.BooleanArray**";
		case STRING_ARR:  return "%struct.StringArray**";
	}
}
//////////////////////////////////////////////////////////////////////////////
char* typeToLLVMAuto(varType type) {
	switch (type) {
		case fVOID: 	  return "void";
		case INTEGER: 	  return "i32";
		case BOOLEAN:     return "i1";
		case INTEGER_ARR: return "%struct.IntArray*";
		case BOOLEAN_ARR: return "%struct.BooleanArray*";
		case STRING_ARR:  return "%struct.StringArray*";
	}	
}
//////////////////////////////////////////////////////////////////////////////
char* structLLVM(varType vType) {
	switch (vType) {
		case INTEGER_ARR:   return "%struct.IntArray";
		case BOOLEAN_ARR: 	return "%struct.BooleanArray";
	}
}
//////////////////////////////////////////////////////////////////////////////
char scopeToLLVM(scope scp) {
	switch (scp) {
		case GLOBAL: 	  		return '@';
		case LOCAL: case PARAM: return '%';
	}	
}
//////////////////////////////////////////////////////////////////////////////
void generateMultStatement(is_MultStatement* iMS) {
	is_MultStatement* auxMult;
	for (auxMult = iMS->next; auxMult; auxMult = auxMult->next) {
		if (auxMult->type == IS_MULT_NULL || auxMult->type == IS_MULTBODY_NULL) 
			return;
		generateStatement(auxMult->iS);
	}
}
//////////////////////////////////////////////////////////////////////////////
void generateStatement(is_Statement* iS) {
	int value, index;
	int K, N;
	if (!iS) return;
	switch (iS->type) {
	case STAT_IFTHENELSE:
		generateExpression(iS->data_declaration.iP->iE);
		K = ++ifN;
		printf("\tbr i1 %%%d, label %%.then_%d, label %%.else_%d\n"
		".then_%d:\n", llvmN, K, K, K);
		generateStatement(iS->data_declaration.iITE->iThenStat);
		printf("\tbr label %%.endIf_%d\n"
		".else_%d:\n", K, K);
		generateStatement(iS->data_declaration.iITE->iElseStat);
		printf("\tbr label %%.endIf_%d\n"
		".endIf_%d:\n", K, K);
		break;
	case STAT_WHILE:
		K = ++whileN;
		printf("\tbr label %%.while_%d\n"
		".while_%d:\n", K, K);
		generateExpression(iS->data_declaration.iW->iE);
		printf("\tbr i1 %%%d, label %%loop_%d, label %%.endWhile_%d\n"
		"loop_%d:\n", llvmN, K, K, K);
		generateStatement(iS->data_declaration.iW->iWhileStat);
		printf("\tbr label %%.while_%d\n"
		".endWhile_%d:\n", K, K);
		break;
	case STAT_PRINT:
		N = generateExpression(iS->data_declaration.iP->iE);
		switch (iS->data_declaration.iP->iE->vType) {
		case BOOLEAN:
			++ifN;
			llvmN++;
			printf("\tbr i1 %%%d, label %%.then_%d, label %%.else_%d\n"
			".then_%d:\n"
			"\tcall i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([6 x i8]* @.true, i32 0, i32 0))\n"
			"\tbr label %%.endIf_%d\n"
			".else_%d:\n"
			"\tcall i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([7 x i8]* @.false, i32 0, i32 0))\n"
			"\tbr label %%.endIf_%d\n"
			".endIf_%d:\n", N, ifN, ifN, ifN, ifN, ifN, ifN, ifN);
			llvmN++;
			break;
		case INTEGER:
			printf("\tcall i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([4 x i8]* @.int, i32 0, i32 0), i32 %%%d)\n", llvmN);
			++llvmN;
			break;
		}
		break;
	case STAT_ARRAY_ASSIGNMENT:
		value = generateExpression(iS->data_declaration.iAA->value);
		index = generateExpression(iS->data_declaration.iAA->index);
		llvmN++;
		printf("\t%%%d = load %s %c%s\n",
			llvmN,
			typeToLLVM(iS->data_declaration.iAA->idType),
			scopeToLLVM(iS->data_declaration.iAA->scp),
			iS->data_declaration.iAA->id
		);
		llvmN++;
		printf("\t%%%d = getelementptr %s %%%d, i32 0, i32 1\n"
			, llvmN, typeToLLVMAuto(iS->data_declaration.iAA->idType)
			, llvmN-1
		);
		llvmN++;
		printf(	"\t%%%d = load %s* %%%d\n"
			, llvmN, typeToLLVM(getArrayType(iS->data_declaration.iAA->idType))
			, llvmN-1
		); 
		llvmN++;
		printf("\t%%%d = getelementptr %s %%%d, i32 %%%d\n"
			, llvmN, typeToLLVM(getArrayType(iS->data_declaration.iAA->idType))
			, llvmN-1, index
		);
		printf("\tstore %s %%%d, %s %%%d\n"
			, typeToLLVMAuto(getArrayType(iS->data_declaration.iAA->idType)), value
			, typeToLLVM(getArrayType(iS->data_declaration.iAA->idType)), llvmN
		);
		break;
	case STAT_ASSIGNMENT:
		generateExpression(iS->data_declaration.iA->iE);
		printf("\tstore %s %%%d, %s %c%s\n", 
			typeToLLVMAuto(iS->data_declaration.iA->idType), llvmN, 
			typeToLLVM(iS->data_declaration.iA->idType),
			scopeToLLVM(iS->data_declaration.iA->scp),
			iS->data_declaration.iA->id);
		break;
	case STAT_MULT:
		generateMultStatement(iS->data_declaration.iM);
		break;
	case STAT_RETURN:
		if(isMain) {
			printf("\tret i32 0\n");
			llvmN++;
			return;
		}
		if(!iS->data_declaration.iR->iE) {
			printf("\tret void\n");
			return;
		}
		generateExpression(iS->data_declaration.iR->iE);
		printf("\tret %s %%%d\n", 
			typeToLLVMAuto(iS->data_declaration.iR->iE->vType), llvmN);
		llvmN++; //icrementar?! É mesmo preciso!!!
		break;
	}
}
//////////////////////////////////////////////////////////////////////////////
int generateExpression(is_Expression* iE) {
	switch (iE->type) {
	case EXPR_NEW_ARR:
		if(iE->data_declaration.iENA->type == INTEGER_ARR) 
			return generateIntArray(iE);
		if(iE->data_declaration.iENA->type == BOOLEAN_ARR) 
			return generateBooleanArray(iE);
	case EXPR_UNI_OPERATORS:
		return generateUniOperators(iE);
	case EXPR_MULT_OPERATORS:
		return generateMultOperators(iE);
	case EXPR1:
		return generateExpr1(iE->data_declaration.expr1);
	}
}
//////////////////////////////////////////////////////////////////////////////
int generateIntArray(is_Expression* iE) {
	int operator;
	int size, sizeBytes, pData, pStruct, pSize, ppData;
	printf(";operatorNewArr\n");
	size = generateExpression(iE->data_declaration.iENA->iE);
	sizeBytes = ++llvmN;
	printf("\t%%%d = mul i32 %%%d, 4\n", sizeBytes, size);
	++llvmN;
	printf("\t%%%d = call i8* @calloc(i32 %%%d, i32 4)\n", llvmN, sizeBytes);
	pData = ++llvmN;
	printf("\t%%%d = bitcast i8* %%%d to i32*\n", pData, llvmN - 1);
	++llvmN;
	printf("\t%%%d = call i8* @malloc(i32 8)\n", llvmN);
	pStruct = ++llvmN;
	printf("\t%%%d = bitcast i8* %%%d to %%struct.IntArray*\n", pStruct, llvmN - 1);
	pSize = ++llvmN;
	printf("\t%%%d = getelementptr %%struct.IntArray* %%%d, i32 0, i32 0\n"
		, pSize, pStruct
	);
	printf("\tstore i32 %%%d, i32* %%%d\n", size, pSize);
	ppData = ++llvmN;
	printf("\t%%%d = getelementptr %%struct.IntArray* %%%d, i32 0, i32 1\n"
		, ppData, pStruct
	);
	printf("\tstore i32* %%%d, i32** %%%d\n", pData, ppData);
	++llvmN;
	printf("\t%%%d = bitcast %%struct.IntArray* %%%d to %%struct.IntArray*\n"
		, llvmN, pStruct
	);
	printf(";endOperatorNewArr\n");
	return llvmN;
}
//////////////////////////////////////////////////////////////////////////////
int generateBooleanArray(is_Expression* iE) {
	int operator;
	int size, sizeBytes, pData, pStruct, pSize, ppData;
	printf(";operatorNewArr\n");
	size = generateExpression(iE->data_declaration.iENA->iE);
	int sizeAux = ++llvmN;
	printf("\t%%%d = udiv i32 %%%d, 8\n", sizeAux, size);
	sizeBytes = ++llvmN;
	printf("\t%%%d = add i32 %%%d, 1\n", sizeBytes, sizeAux);
	++llvmN;
	printf("\t%%%d = call i8* @calloc(i32 %%%d, i32 1)\n", llvmN, sizeBytes); // array
	pData = ++llvmN;
	printf("\t%%%d = bitcast i8* %%%d to i1*\n", pData, llvmN - 1); 
	++llvmN;
	printf("\t%%%d = call i8* @malloc(i32 8)\n", llvmN); // estrutura
	pStruct = ++llvmN;
	printf("\t%%%d = bitcast i8* %%%d to %%struct.BooleanArray*\n", 
		pStruct, llvmN - 1
	);
	pSize = ++llvmN;
	printf("\t%%%d = getelementptr inbounds %s %%%d, i32 0, i32 0\n"
		, pSize, typeToLLVMAuto(iE->data_declaration.iENA->type), pStruct);
	printf("\tstore i32 %%%d, i32* %%%d\n", size, pSize);
	ppData = ++llvmN;
	printf("\t%%%d = getelementptr %%struct.BooleanArray* %%%d, i32 0, i32 1\n",
		ppData, pStruct
	);
	printf("\tstore i1* %%%d, i1** %%%d\n", pData, ppData);
	++llvmN;
	printf("\t%%%d = bitcast %%struct.BooleanArray* %%%d to %%struct.BooleanArray*\n",
		llvmN, pStruct
	);
	printf(";endOperatorNewArr\n");
	return llvmN;
}
//////////////////////////////////////////////////////////////////////////////
int generateExpr1(is_Expr1* iE1) {
	int N, array, index, stringArr, indexPlusOne;
	char* id;
	switch (iE1->type) {
	case CRV_EXPR:
		return generateExpression(iE1->data_declaration.iCE->iE);
	case DOTLEN_EXPR:
		N = generateExpression(iE1->data_declaration.iCE->iE);
		llvmN++;
		printf("\t%%%d = getelementptr %s %%%d, i32 0, i32 0\n",
			llvmN, typeToLLVMAuto(iE1->data_declaration.iDE->iE->vType), N
		);
		llvmN++;
		printf("\t%%%d = load i32* %%%d\n", llvmN, llvmN - 1);
		return llvmN;
	case BOOLVALUE:
		llvmN++;
		printf("\t%%%d = add i1 0, %d\n", llvmN, iE1->data_declaration.iIV->value);
		return llvmN;
	case INTVALUE:
		llvmN++;
		printf("\t%%%d = add nsw i32 0, %d\n", llvmN, iE1->data_declaration.iIV->intValue);
		return llvmN;
	case IDTF:
		llvmN++;
		char* type;
		switch (iE1->data_declaration.iI->scp) {
		case LOCAL: case PARAM:
			type = typeToLLVM(iE1->vType);

			printf("\t%%%d = load %s %%%s\n",
				llvmN, type, iE1->data_declaration.iI->id);
			return llvmN;
		case GLOBAL:
			type = typeToLLVM(iE1->vType);
			printf("\t%%%d = load %s @%s\n",
				llvmN, type, iE1->data_declaration.iI->id);
			return llvmN;
		}
		return llvmN;
	case METHOD_CALL:
		return generateMethodCall(iE1);
	case PARSEINT_ID_EXPR:
		id = iE1->data_declaration.iPIE->id;
		index = generateExpression(iE1->data_declaration.iPIE->iE);
		llvmN++;
		printf("\t%%%d = load %%struct.StringArray** %%%s\n", llvmN, id);
		llvmN++;
		printf("\t%%%d = getelementptr %%struct.StringArray* %%%d, i32 0, i32 1\n",
			llvmN, llvmN -1);
		stringArr = ++llvmN;
		printf("\t%%%d = load i8*** %%%d\n", llvmN, llvmN-1);
		++llvmN;
		printf("\t%%%d = getelementptr i8** %%%d, i32 %%%d\n",
			llvmN, stringArr, index
		);
		llvmN++;
		printf("\t%%%d = load i8** %%%d\n", llvmN, llvmN-1);
		llvmN++;
		printf("\t%%%d = call i32 @atoi(i8* %%%d)\n", llvmN, llvmN-1);
		return llvmN;
	case EXPR_ARR_INDEX:
		index = generateExpression(iE1->data_declaration.iEAI->iE);
		array = generateExpr1(iE1->data_declaration.iEAI->iE1);
		llvmN++;
		printf("\t%%%d = getelementptr %s %%%d, i32 0, i32 1\n"
			, llvmN, typeToLLVMAuto(iE1->data_declaration.iEAI->arrayType), array
		);
		llvmN++;
		printf("\t%%%d = load %s* %%%d\n"
			, llvmN
			, typeToLLVM(getArrayType(iE1->data_declaration.iEAI->arrayType))
			, llvmN-1
		);
		llvmN++;		
		printf("\t%%%d = getelementptr %s %%%d, i32 %%%d\n"
			, llvmN, typeToLLVM(getArrayType(iE1->data_declaration.iEAI->arrayType))
			, llvmN -1, index
		);
		llvmN++;
		printf("\t%%%d = load %s %%%d\n"
			, llvmN, typeToLLVM(getArrayType(iE1->data_declaration.iEAI->arrayType))
			, llvmN-1
		);
		return llvmN;
	}
}
//////////////////////////////////////////////////////////////////////////////
int generateMultOperators(is_Expression* iE) {
	if 	(iE->data_declaration.iEMO->type == E){
		return generateShortCircuitAnd(iE);
	}
	if(iE->data_declaration.iEMO->type == OU) {
		return generateShortCircuitOr(iE);
	}
	operType operator;
	generateExpression(iE->data_declaration.iEMO->operand1);
	int n1 = llvmN;

	generateExpression(iE->data_declaration.iEMO->operand2);
	int n2 = llvmN;
	llvmN++;
	int isIf, isElse, isEndif;
	operator = iE->data_declaration.iEMO->type;
	switch (operator) {
	case IG:	
		printf("\t%%%d = icmp eq %s %%%d, %%%d\n"
			, llvmN, typeToLLVMAuto(iE->data_declaration.iEMO->operand1->vType),
			n1, n2
		);
		return llvmN;
	case NAO_IG:	
		printf("\t%%%d = icmp ne %s %%%d, %%%d\n"
			, llvmN, typeToLLVMAuto(iE->data_declaration.iEMO->operand1->vType)
			, n1, n2
		);
		return llvmN; 
	case MAIOR:	
		printf("\t%%%d = icmp sgt i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case MENOR:	
		printf("\t%%%d = icmp slt i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case IG_MAIOR:	
		printf("\t%%%d = icmp sge i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case IG_MENOR:	
		printf("\t%%%d = icmp sle i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case SOMA:	
		printf("\t%%%d = add i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case TIRA:	
		printf("\t%%%d = sub i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case ASTERISC:	
		printf("\t%%%d = mul i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case DIVIDE:	
		printf("\t%%%d = sdiv i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	case RESTO:	
		printf("\t%%%d = srem i32 %%%d, %%%d\n", llvmN, n1, n2);
		return llvmN;
	}
}
//////////////////////////////////////////////////////////////////////////////
int generateShortCircuitAnd(is_Expression* iE) {
	operType operator;
	generateExpression(iE->data_declaration.iEMO->operand1);
	int n1 = llvmN++;
	int isIf, isElse, isEndif, realValue, n2;
	operator = iE->data_declaration.iEMO->type;
	printf("\t%%%d = alloca i1\n", llvmN);
	realValue = llvmN;
	isEndif = isElse  = isIf = ++ifN;
	printf("\tbr i1 %%%d, label %%.then_%d, label %%.else_%d\n", n1, isIf, isElse);
	
	printf(".then_%d:\n", isIf);
	generateExpression(iE->data_declaration.iEMO->operand2);
	n2 = llvmN++;
	printf("\tstore i1 %%%d, i1* %%%d\n", n2, realValue);
	printf("\tbr label %%.endIf_%d\n", isEndif);
	
	printf(".else_%d:\n", isElse);
	printf("\tstore i1 0, i1* %%%d\n", realValue);
	printf("\tbr label %%.endIf_%d\n", isEndif);
	printf(".endIf_%d:\n", isEndif);
	
	printf("\t%%%d= load i1* %%%d\n", llvmN, realValue);
	return llvmN;
}
//////////////////////////////////////////////////////////////////////////////
int generateShortCircuitOr(is_Expression* iE) {
	operType operator;
	generateExpression(iE->data_declaration.iEMO->operand1);
	int n1 = llvmN++;
	int isIf, isElse, isEndif, realValue, n2;
	operator = iE->data_declaration.iEMO->type;
	printf("\t%%%d = alloca i1\n", llvmN);
	realValue = llvmN;
	isEndif = isElse  = isIf = ++ifN;
	printf("\tbr i1 %%%d, label %%.then_%d, label %%.else_%d\n", n1, isIf, isElse);
	
	printf(".then_%d:\n", isIf);
	printf("\tstore i1 1, i1* %%%d\n", realValue);
	printf("\tbr label %%.endIf_%d\n", isEndif);
	
	printf(".else_%d:\n", isElse);
	generateExpression(iE->data_declaration.iEMO->operand2);
	n2 = llvmN++;
	printf("\tstore i1 %%%d, i1* %%%d\n", n2, realValue);
	printf("\tbr label %%.endIf_%d\n", isEndif);
	printf(".endIf_%d:\n", isEndif);
	
	printf("\t%%%d= load i1* %%%d\n", llvmN, realValue);
	return llvmN;
}
//////////////////////////////////////////////////////////////////////////////
int generateUniOperators(is_Expression* iE) {
	operType operator;
	generateExpression(iE->data_declaration.iEUO->operand);
	int n = llvmN;
	llvmN++;
	operator = iE->data_declaration.iEUO->type;
	switch (operator) {
	case NEGA:		
		printf("\t%%%d = xor i1 1, %%%d\n", llvmN, n);
		return llvmN;
	case PLUS:
		llvmN--;
		return llvmN;
	case MINUS:	
		printf("\t%%%d = sub i32 0, %%%d\n", llvmN, n);	
		return llvmN;
	}
}
//////////////////////////////////////////////////////////////////////////////
int generateMethodCall(is_Expr1* iE1) {
	int varArr[NSYMS];
	int i1 = 0;
	is_MultExpression* curr = iE1->data_declaration.iMC->iME->next;
	printf(";generateMethodCall\n");
	for (; curr; curr = curr->next, ++i1) {
		generateExpression(curr->iE);
		printf("\t%%%d = alloca %s\n", llvmN + 1, typeToLLVMAuto(curr->iE->vType));
		printf("\tstore %s %%%d, %s %%%d\n", 
			typeToLLVMAuto(curr->iE->vType), llvmN, typeToLLVM(curr->iE->vType), llvmN + 1
		);
		llvmN++;
		varArr[i1] = llvmN;
	}
	llvmN++;
	printf("\t%%%d = call %s @%s(", llvmN, typeToLLVMAuto(iE1->vType), 
		    iE1->data_declaration.iMC->id);
	if (i1 == 0) {
	 	printf(")\n");
		return llvmN;
	}

	int i2 = 0;
	curr = iE1->data_declaration.iMC->iME->next;
	printf("%s %%%d", typeToLLVM(curr->iE->vType), varArr[0]);
	for (curr = curr->next, i2 = 1; i2 < i1; curr = curr->next, ++i2) {
		printf(", %s %%%d", typeToLLVM(curr->iE->vType), varArr[i2]);
	}
	printf(")\n");
	return llvmN;
}
