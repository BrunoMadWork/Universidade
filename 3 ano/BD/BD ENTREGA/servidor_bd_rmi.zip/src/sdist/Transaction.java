package sdist;
//Create table pedidos (name VARCHAR(50),idea_key NUMERIC(15,0), limite Numeric(30,10),numero_acções Numeric (30,0),ordem Numeric(15,0),PRIMARY KEY(name,idea_key))
public class Transaction {
	private String nome;
	private int idea_key;
	private float limite;
	private float numero;
	private int order;
	public Transaction(String nome, int idea_key, float limite, float numero,
			int order) {
		super();
		this.nome = nome;
		this.idea_key = idea_key;
		this.limite = limite;
		this.numero = numero;
		this.order = order;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdea_key() {
		return idea_key;
	}
	public void setIdea_key(int idea_key) {
		this.idea_key = idea_key;
	}
	public float getLimite() {
		return limite;
	}
	public void setLimite(float limite) {
		this.limite = limite;
	}
	public float getNumero() {
		return numero;
	}
	public void setNumero(float numero) {
		this.numero = numero;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
}