package sdist;

import java.rmi.*;

public interface Notificacoes extends Remote{
	
	public void print_on_client(String s) throws java.rmi.RemoteException;
	void notificate_users(String texto) throws RemoteException;

}
