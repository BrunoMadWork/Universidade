package sdist;

import java.io.Serializable;
import java.util.Date;

public class User implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String _userName;  
	private String _loginDate;
	private int isRoot;
  


public User()
  {
    _loginDate = (new Date()).toString();
  }

  public void setUserName(String userName)
  {
    _userName = userName;
  }
    
  public String getUserName()
  {
    return _userName;
  }      
  
 
  
  public String getLoginDate()
  {
    return _loginDate;
  }
  public int getIsRoot() {
	return isRoot;
}

public void setIsRoot(int isRoot) {
	this.isRoot = isRoot;
}
    
}