package sdist;

import java.io.Serializable;
import java.util.ArrayList;

import javax.websocket.Session;

public class Login_data_bucket implements Serializable {
	ArrayList<String> array;
	ArrayList<Integer> array_ints;
	public Login_data_bucket(ArrayList<String> array,
			ArrayList<Integer> array_ints) {
		super();
		this.array = array;
		this.array_ints = array_ints;
	}
	public ArrayList<String> getArray() {
	
		return array;
	}
	public void setArray(ArrayList<String> array) {
		this.array = array;
	}
	public ArrayList<Integer> getArray_ints() {
		return array_ints;
	}
	public void setArray_ints(ArrayList<Integer> array_ints) {
		this.array_ints = array_ints;
	}
	
}
