package sdist;


import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.*;





public class Login_Bean implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Login_data_bucket array_nomes;

	
	
	public Login_Bean(){
		array_nomes=null;
	}
	public Login_data_bucket getArray_nomes(Bd bd) {
		setArray_nomes (bd);
		return array_nomes;
	}

	public void setArray_nomes(Bd bd) {
		array_nomes=null;
		try {
			array_nomes = bd.getNomes();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public String get_password(Bd bd, String nome){
		setArray_nomes (bd);
		try {
			return bd.get_password(nome);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public void insert_user(String nome,String password, Bd bd){
		setArray_nomes (bd); //seguranca
		try {
			bd.put_reg_data( nome,  password);
			bd.put_beg_acount_data( nome, 1000000);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setArray_nomes (bd);
	}// seguranca
}
