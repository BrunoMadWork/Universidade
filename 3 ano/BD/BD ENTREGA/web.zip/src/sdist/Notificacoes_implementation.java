package sdist;
import sdist.Bd;
import sdist.ChatWebSocketServlet.ChatMessageInbound;

import java.rmi.*;
import java.rmi.server.*;
import java.net.*;
import java.io.*;

import javax.servlet.ServletException;

public class Notificacoes_implementation extends UnicastRemoteObject implements Notificacoes {

	/**
	 * 
	 */
	private ChatMessageInbound sender;
	private static final long serialVersionUID = 1L;
	Bd bd;
	public Notificacoes_implementation(ChatMessageInbound chatMessageInbound) throws RemoteException {
		
		  bd=null;
			try {
				System.getProperties().put("java.security.policy", "policy.all");
				//System.setSecurityManager(new RMISecurityManager());
				bd = (Bd) Naming.lookup("rmi://localhost:7000/Bd");
				bd.subscribe("Bd", (Notificacoes) this);
				this.sender=chatMessageInbound;


			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NotBoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	
	@Override
	public void print_on_client(String s) throws RemoteException {
		// TODO Auto-generated method stub
	}

	@Override
	public void notificate_users( String texto) throws RemoteException {
		// TODO Auto-generated method stub
		
		
			sender.broadcast(texto);
		
	}
	
	

	
}
